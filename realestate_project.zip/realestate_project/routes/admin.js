const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { verifyToken, adminOnly } = require('../middleware/auth');

// Apply authentication to all admin routes
router.use(verifyToken);
router.use(adminOnly);

// =============================================
// DASHBOARD STATISTICS
// =============================================

router.get('/dashboard', async (req, res) => {
    try {
        const [results] = await pool.query(`
            SELECT
                (SELECT COUNT(*) FROM Property) as properties,
                (SELECT COUNT(*) FROM Agent WHERE is_active = TRUE) as agents,
                (SELECT COUNT(*) FROM Client WHERE is_active = TRUE) as clients,
                (SELECT COUNT(*) FROM Listing WHERE listing_status = 'Active') as activeListings,
                (SELECT COUNT(*) FROM Transaction WHERE status = 'Completed') as completedTransactions,
                (SELECT COALESCE(SUM(amount), 0) FROM Transaction WHERE status = 'Completed') as totalSales,
                (SELECT COUNT(*) FROM Transaction WHERE status = 'Pending') as pendingTransactions,
                (SELECT COUNT(*) FROM Contract WHERE status = 'Active') as activeContracts,
                (SELECT COUNT(*) FROM Property WHERE status = 'Sold') as propertiesSold,
                (SELECT COUNT(*) FROM Property WHERE status = 'Rented') as propertiesRented
        `);

        res.json(results[0]);
    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});


// =============================================
// AGENCY MANAGEMENT (CRUD)
// =============================================

router.get('/agencies', async (req, res) => {
    try {
        const [agencies] = await pool.query('SELECT * FROM Agency ORDER BY created_at DESC');
        res.json(agencies);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/agencies/:id', async (req, res) => {
    try {
        const [agencies] = await pool.query('SELECT * FROM Agency WHERE agency_id = ?', [req.params.id]);
        if (agencies.length === 0) return res.status(404).json({ error: 'Agency not found' });
        res.json(agencies[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/agencies', async (req, res) => {
    try {
        const { agency_name, email, password, phone, address, license_number } = req.body;

        if (!agency_name || !email || !password) {
            return res.status(400).json({ error: 'Agency name, email, and password are required' });
        }

        // Check if email exists
        const [existing] = await pool.query('SELECT agency_id FROM Agency WHERE email = ?', [email]);
        if (existing.length > 0) {
            return res.status(409).json({ error: 'Email already registered' });
        }

        const bcrypt = require('bcryptjs');
        const hashedPassword = await bcrypt.hash(password, 10);

        const [result] = await pool.query(
            `INSERT INTO Agency (agency_name, email, password, phone, address, license_number) 
             VALUES (?, ?, ?, ?, ?, ?)`,
            [agency_name, email, hashedPassword, phone, address, license_number]
        );
        res.status(201).json({ success: true, id: result.insertId, message: 'Agency created successfully' });
    } catch (error) {
        console.error('Create agency error:', error);
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ error: 'Email or license number already exists' });
        }
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/agencies/:id', async (req, res) => {
    try {
        const { agency_name, phone, address, license_number, is_active } = req.body;
        await pool.query(
            'UPDATE Agency SET agency_name = ?, phone = ?, address = ?, license_number = ?, is_active = ? WHERE agency_id = ?',
            [agency_name, phone, address, license_number, is_active, req.params.id]
        );
        res.json({ success: true, message: 'Agency updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/agencies/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Agency WHERE agency_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Agency deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// AGENT MANAGEMENT (CRUD)
// =============================================

router.get('/agents', async (req, res) => {
    try {
        const [agents] = await pool.query(`
            SELECT a.*, ag.agency_name 
            FROM Agent a 
            JOIN Agency ag ON a.agency_id = ag.agency_id 
            ORDER BY a.created_at DESC
        `);
        res.json(agents);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/agents/:id', async (req, res) => {
    try {
        const [agents] = await pool.query(`
            SELECT a.*, ag.agency_name 
            FROM Agent a 
            JOIN Agency ag ON a.agency_id = ag.agency_id 
            WHERE a.agent_id = ?
        `, [req.params.id]);
        if (agents.length === 0) return res.status(404).json({ error: 'Agent not found' });
        res.json(agents[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/agents', async (req, res) => {
    try {
        const { agency_id, first_name, last_name, email, password, phone, license_number, commission_rate } = req.body;
        const bcrypt = require('bcryptjs');
        const hashedPassword = await bcrypt.hash(password, 10);

        const [result] = await pool.query(
            `INSERT INTO Agent (agency_id, first_name, last_name, email, password, phone, license_number, commission_rate, hire_date) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURDATE())`,
            [agency_id, first_name, last_name, email, hashedPassword, phone, license_number, commission_rate || 2.50]
        );
        res.status(201).json({ success: true, id: result.insertId, message: 'Agent created successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/agents/:id', async (req, res) => {
    try {
        const { first_name, last_name, phone, license_number, commission_rate, is_active } = req.body;
        await pool.query(
            'UPDATE Agent SET first_name = ?, last_name = ?, phone = ?, license_number = ?, commission_rate = ?, is_active = ? WHERE agent_id = ?',
            [first_name, last_name, phone, license_number, commission_rate, is_active, req.params.id]
        );
        res.json({ success: true, message: 'Agent updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/agents/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Agent WHERE agent_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Agent deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// CLIENT MANAGEMENT (CRUD)
// =============================================

router.get('/clients', async (req, res) => {
    try {
        const [clients] = await pool.query('SELECT * FROM Client ORDER BY created_at DESC');
        res.json(clients);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/clients/:id', async (req, res) => {
    try {
        const [clients] = await pool.query('SELECT * FROM Client WHERE client_id = ?', [req.params.id]);
        if (clients.length === 0) return res.status(404).json({ error: 'Client not found' });
        res.json(clients[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/clients', async (req, res) => {
    try {
        const { first_name, last_name, email, password, phone, address, cnic, client_type } = req.body;

        if (!first_name || !last_name || !email || !password) {
            return res.status(400).json({ error: 'First name, last name, email, and password are required' });
        }

        // Check if email exists
        const [existing] = await pool.query('SELECT client_id FROM Client WHERE email = ?', [email]);
        if (existing.length > 0) {
            return res.status(409).json({ error: 'Email already registered' });
        }

        const bcrypt = require('bcryptjs');
        const hashedPassword = await bcrypt.hash(password, 10);

        const [result] = await pool.query(
            `INSERT INTO Client (first_name, last_name, email, password, phone, address, cnic, client_type) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [first_name, last_name, email, hashedPassword, phone, address, cnic, client_type || 'Buyer']
        );
        res.status(201).json({ success: true, id: result.insertId, message: 'Client created successfully' });
    } catch (error) {
        console.error('Create client error:', error);
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ error: 'Email or CNIC already exists' });
        }
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/clients/:id', async (req, res) => {
    try {
        const { first_name, last_name, phone, address, cnic, client_type, is_active } = req.body;
        await pool.query(
            'UPDATE Client SET first_name = ?, last_name = ?, phone = ?, address = ?, cnic = ?, client_type = ?, is_active = ? WHERE client_id = ?',
            [first_name, last_name, phone, address, cnic, client_type, is_active, req.params.id]
        );
        res.json({ success: true, message: 'Client updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/clients/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Client WHERE client_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Client deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// PROPERTY TYPE MANAGEMENT (CRUD)
// =============================================

router.get('/property-types', async (req, res) => {
    try {
        const [types] = await pool.query('SELECT * FROM Property_Type ORDER BY type_name');
        res.json(types);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/property-types/:id', async (req, res) => {
    try {
        const [types] = await pool.query('SELECT * FROM Property_Type WHERE type_id = ?', [req.params.id]);
        if (types.length === 0) return res.status(404).json({ error: 'Property type not found' });
        res.json(types[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/property-types', async (req, res) => {
    try {
        const { type_name, description } = req.body;
        const [result] = await pool.query(
            'INSERT INTO Property_Type (type_name, description) VALUES (?, ?)',
            [type_name, description]
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/property-types/:id', async (req, res) => {
    try {
        const { type_name, description } = req.body;
        await pool.query(
            'UPDATE Property_Type SET type_name = ?, description = ? WHERE type_id = ?',
            [type_name, description, req.params.id]
        );
        res.json({ success: true, message: 'Property type updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/property-types/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Property_Type WHERE type_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Property type deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// LOCATION MANAGEMENT (CRUD)
// =============================================

router.get('/locations', async (req, res) => {
    try {
        const [locations] = await pool.query('SELECT * FROM Location ORDER BY created_at DESC');
        res.json(locations);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/locations/:id', async (req, res) => {
    try {
        const [locations] = await pool.query('SELECT * FROM Location WHERE location_id = ?', [req.params.id]);
        if (locations.length === 0) return res.status(404).json({ error: 'Location not found' });
        res.json(locations[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/locations', async (req, res) => {
    try {
        const { address, city, area, postal_code } = req.body;
        const [result] = await pool.query(
            'INSERT INTO Location (address, city, area, postal_code) VALUES (?, ?, ?, ?)',
            [address, city || 'Islamabad', area, postal_code]
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/locations/:id', async (req, res) => {
    try {
        const { address, city, area, postal_code } = req.body;
        await pool.query(
            'UPDATE Location SET address = ?, city = ?, area = ?, postal_code = ? WHERE location_id = ?',
            [address, city, area, postal_code, req.params.id]
        );
        res.json({ success: true, message: 'Location updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/locations/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Location WHERE location_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Location deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// PROPERTY MANAGEMENT (CRUD)
// =============================================

router.get('/properties', async (req, res) => {
    try {
        const [properties] = await pool.query(`
            SELECT p.*, pt.type_name, l.address, l.area, l.city,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name
            FROM Property p
            JOIN Property_Type pt ON p.type_id = pt.type_id
            JOIN Location l ON p.location_id = l.location_id
            JOIN Agent a ON p.agent_id = a.agent_id
            ORDER BY p.created_at DESC
        `);
        res.json(properties);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/properties/:id', async (req, res) => {
    try {
        const [properties] = await pool.query(`
            SELECT p.*, pt.type_name, l.address, l.area, l.city,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name
            FROM Property p
            JOIN Property_Type pt ON p.type_id = pt.type_id
            JOIN Location l ON p.location_id = l.location_id
            JOIN Agent a ON p.agent_id = a.agent_id
            WHERE p.property_id = ?
        `, [req.params.id]);
        if (properties.length === 0) return res.status(404).json({ error: 'Property not found' });
        res.json(properties[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/properties', async (req, res) => {
    try {
        const { agent_id, type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for } = req.body;
        const [result] = await pool.query(
            `INSERT INTO Property (agent_id, type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [agent_id, type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status || 'Available', property_for || 'Sale']
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/properties/:id', async (req, res) => {
    try {
        const { agent_id, type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for } = req.body;
        await pool.query(
            `UPDATE Property SET agent_id = ?, type_id = ?, location_id = ?, title = ?, description = ?, price = ?, 
             area_sqft = ?, bedrooms = ?, bathrooms = ?, year_built = ?, status = ?, property_for = ? WHERE property_id = ?`,
            [agent_id, type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for, req.params.id]
        );
        res.json({ success: true, message: 'Property updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/properties/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Property WHERE property_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Property deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// LISTING MANAGEMENT (CRUD)
// =============================================

router.get('/listings', async (req, res) => {
    try {
        const [listings] = await pool.query(`
            SELECT l.*, p.title as property_title, p.price as property_price,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name
            FROM Listing l
            JOIN Property p ON l.property_id = p.property_id
            JOIN Agent a ON l.agent_id = a.agent_id
            ORDER BY l.created_at DESC
        `);
        res.json(listings);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/listings/:id', async (req, res) => {
    try {
        const [listings] = await pool.query(`
            SELECT l.*, p.title as property_title, p.price as property_price,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name
            FROM Listing l
            JOIN Property p ON l.property_id = p.property_id
            JOIN Agent a ON l.agent_id = a.agent_id
            WHERE l.listing_id = ?
        `, [req.params.id]);
        if (listings.length === 0) return res.status(404).json({ error: 'Listing not found' });
        res.json(listings[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/listings', async (req, res) => {
    try {
        const { property_id, agent_id, listing_date, expiry_date, listing_price, listing_status, description, featured } = req.body;
        const [result] = await pool.query(
            `INSERT INTO Listing (property_id, agent_id, listing_date, expiry_date, listing_price, listing_status, description, featured)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [property_id, agent_id, listing_date, expiry_date, listing_price, listing_status || 'Active', description, featured || false]
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/listings/:id', async (req, res) => {
    try {
        const { listing_price, listing_status, description, featured, expiry_date } = req.body;
        await pool.query(
            'UPDATE Listing SET listing_price = ?, listing_status = ?, description = ?, featured = ?, expiry_date = ? WHERE listing_id = ?',
            [listing_price, listing_status, description, featured, expiry_date, req.params.id]
        );
        res.json({ success: true, message: 'Listing updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/listings/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Listing WHERE listing_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Listing deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// TRANSACTION MANAGEMENT (CRUD)
// =============================================

router.get('/transactions', async (req, res) => {
    try {
        const [transactions] = await pool.query(`
            SELECT t.*, CONCAT(c.first_name, ' ', c.last_name) as client_name,
                   p.title as property_title,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name
            FROM Transaction t
            JOIN Client c ON t.client_id = c.client_id
            JOIN Listing l ON t.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            JOIN Agent a ON l.agent_id = a.agent_id
            ORDER BY t.transaction_date DESC
        `);
        res.json(transactions);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/transactions/:id', async (req, res) => {
    try {
        const [transactions] = await pool.query(`
            SELECT t.*, CONCAT(c.first_name, ' ', c.last_name) as client_name,
                   p.title as property_title,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name
            FROM Transaction t
            JOIN Client c ON t.client_id = c.client_id
            JOIN Listing l ON t.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            JOIN Agent a ON l.agent_id = a.agent_id
            WHERE t.transaction_id = ?
        `, [req.params.id]);
        if (transactions.length === 0) return res.status(404).json({ error: 'Transaction not found' });
        res.json(transactions[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/transactions', async (req, res) => {
    try {
        const { listing_id, client_id, transaction_type, transaction_date, amount, commission, status, notes } = req.body;
        const [result] = await pool.query(
            `INSERT INTO Transaction (listing_id, client_id, transaction_type, transaction_date, amount, commission, status, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [listing_id, client_id, transaction_type, transaction_date, amount, commission, status || 'Pending', notes]
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/transactions/:id', async (req, res) => {
    try {
        const { amount, commission, status, notes } = req.body;
        await pool.query(
            'UPDATE Transaction SET amount = ?, commission = ?, status = ?, notes = ? WHERE transaction_id = ?',
            [amount, commission, status, notes, req.params.id]
        );
        res.json({ success: true, message: 'Transaction updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/transactions/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Transaction WHERE transaction_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Transaction deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// PAYMENT MANAGEMENT (CRUD)
// =============================================

router.get('/payments', async (req, res) => {
    try {
        const [payments] = await pool.query(`
            SELECT pay.*, t.amount as transaction_amount, t.status as transaction_status,
                   CONCAT(c.first_name, ' ', c.last_name) as client_name
            FROM Payment pay
            JOIN Transaction t ON pay.transaction_id = t.transaction_id
            JOIN Client c ON t.client_id = c.client_id
            ORDER BY pay.payment_date DESC
        `);
        res.json(payments);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/payments/:id', async (req, res) => {
    try {
        const [payments] = await pool.query(`
            SELECT pay.*, t.amount as transaction_amount, t.status as transaction_status
            FROM Payment pay
            JOIN Transaction t ON pay.transaction_id = t.transaction_id
            WHERE pay.payment_id = ?
        `, [req.params.id]);
        if (payments.length === 0) return res.status(404).json({ error: 'Payment not found' });
        res.json(payments[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/payments', async (req, res) => {
    try {
        const { transaction_id, payment_date, amount, payment_method, payment_status, reference_number, notes } = req.body;
        const [result] = await pool.query(
            `INSERT INTO Payment (transaction_id, payment_date, amount, payment_method, payment_status, reference_number, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [transaction_id, payment_date, amount, payment_method || 'Bank Transfer', payment_status || 'Pending', reference_number, notes]
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/payments/:id', async (req, res) => {
    try {
        const { amount, payment_method, payment_status, reference_number, notes } = req.body;
        await pool.query(
            'UPDATE Payment SET amount = ?, payment_method = ?, payment_status = ?, reference_number = ?, notes = ? WHERE payment_id = ?',
            [amount, payment_method, payment_status, reference_number, notes, req.params.id]
        );
        res.json({ success: true, message: 'Payment updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/payments/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Payment WHERE payment_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Payment deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// CONTRACT MANAGEMENT (CRUD)
// =============================================

router.get('/contracts', async (req, res) => {
    try {
        const [contracts] = await pool.query(`
            SELECT con.*, t.amount as transaction_amount,
                   CONCAT(c.first_name, ' ', c.last_name) as client_name,
                   p.title as property_title
            FROM Contract con
            JOIN Transaction t ON con.transaction_id = t.transaction_id
            JOIN Client c ON t.client_id = c.client_id
            JOIN Listing l ON t.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            ORDER BY con.contract_date DESC
        `);
        res.json(contracts);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/contracts/:id', async (req, res) => {
    try {
        const [contracts] = await pool.query(`
            SELECT con.*, t.amount as transaction_amount,
                   CONCAT(c.first_name, ' ', c.last_name) as client_name,
                   p.title as property_title
            FROM Contract con
            JOIN Transaction t ON con.transaction_id = t.transaction_id
            JOIN Client c ON t.client_id = c.client_id
            JOIN Listing l ON t.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            WHERE con.contract_id = ?
        `, [req.params.id]);

        if (contracts.length === 0) {
            return res.status(404).json({ error: 'Contract not found' });
        }
        res.json(contracts[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/contracts', async (req, res) => {
    try {
        const { transaction_id, contract_date, start_date, end_date, terms, contract_type, status, document_path } = req.body;
        const [result] = await pool.query(
            `INSERT INTO Contract (transaction_id, contract_date, start_date, end_date, terms, contract_type, status, document_path)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [transaction_id, contract_date, start_date, end_date, terms, contract_type, status || 'Draft', document_path]
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/contracts/:id', async (req, res) => {
    try {
        const { contract_date, start_date, end_date, terms, contract_type, status, document_path } = req.body;
        await pool.query(
            `UPDATE Contract SET contract_date = ?, start_date = ?, end_date = ?, terms = ?, 
             contract_type = ?, status = ?, document_path = ? WHERE contract_id = ?`,
            [contract_date, start_date, end_date || null, terms, contract_type, status, document_path, req.params.id]
        );
        res.json({ success: true, message: 'Contract updated successfully' });
    } catch (error) {
        console.error('Contract update error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/contracts/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Contract WHERE contract_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Contract deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// INSPECTION MANAGEMENT (CRUD)
// =============================================

router.get('/inspections', async (req, res) => {
    try {
        const [inspections] = await pool.query(`
            SELECT i.*, CONCAT(c.first_name, ' ', c.last_name) as client_name,
                   p.title as property_title,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name
            FROM Inspection i
            JOIN Client c ON i.client_id = c.client_id
            JOIN Listing l ON i.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            JOIN Agent a ON l.agent_id = a.agent_id
            ORDER BY i.inspection_date DESC
        `);
        res.json(inspections);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/inspections', async (req, res) => {
    try {
        const { listing_id, client_id, inspection_date, inspection_time, status, notes } = req.body;
        const [result] = await pool.query(
            `INSERT INTO Inspection (listing_id, client_id, inspection_date, inspection_time, status, notes)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [listing_id, client_id, inspection_date, inspection_time, status || 'Scheduled', notes]
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/inspections/:id', async (req, res) => {
    try {
        const { inspection_date, inspection_time, status, notes, agent_feedback } = req.body;
        await pool.query(
            'UPDATE Inspection SET inspection_date = ?, inspection_time = ?, status = ?, notes = ?, agent_feedback = ? WHERE inspection_id = ?',
            [inspection_date, inspection_time, status, notes, agent_feedback, req.params.id]
        );
        res.json({ success: true, message: 'Inspection updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/inspections/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Inspection WHERE inspection_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Inspection deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// FEEDBACK MANAGEMENT (CRUD)
// =============================================

router.get('/feedback', async (req, res) => {
    try {
        const [feedback] = await pool.query(`
            SELECT f.*, CONCAT(c.first_name, ' ', c.last_name) as client_name,
                   p.title as property_title
            FROM Feedback f
            JOIN Client c ON f.client_id = c.client_id
            JOIN Listing l ON f.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            ORDER BY f.feedback_date DESC
        `);
        res.json(feedback);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/feedback/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Feedback WHERE feedback_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Feedback deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// REPORTS
// =============================================

router.get('/reports/sales-by-agent', async (req, res) => {
    try {
        const [report] = await pool.query(`
            SELECT CONCAT(a.first_name, ' ', a.last_name) as agent_name,
                   COUNT(t.transaction_id) as total_transactions,
                   SUM(CASE WHEN t.status = 'Completed' THEN t.amount ELSE 0 END) as total_sales,
                   SUM(CASE WHEN t.status = 'Completed' THEN t.commission ELSE 0 END) as total_commission
            FROM Agent a
            LEFT JOIN Listing l ON a.agent_id = l.agent_id
            LEFT JOIN Transaction t ON l.listing_id = t.listing_id
            GROUP BY a.agent_id
            ORDER BY total_sales DESC
        `);
        res.json(report);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/reports/properties-by-type', async (req, res) => {
    try {
        const [report] = await pool.query(`
            SELECT pt.type_name, COUNT(p.property_id) as count,
                   AVG(p.price) as avg_price,
                   MIN(p.price) as min_price,
                   MAX(p.price) as max_price
            FROM Property_Type pt
            LEFT JOIN Property p ON pt.type_id = p.type_id
            GROUP BY pt.type_id
        `);
        res.json(report);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;
