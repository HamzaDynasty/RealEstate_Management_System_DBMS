const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { verifyToken, authorize } = require('../middleware/auth');

// Apply authentication to all client routes
router.use(verifyToken);
router.use(authorize('client', 'admin'));

// =============================================
// CLIENT DASHBOARD
// =============================================

router.get('/dashboard', async (req, res) => {
    try {
        const clientId = req.user.id;

        // Optimized single query using subqueries instead of multiple round trips
        const [results] = await pool.query(`
            SELECT 
                (SELECT COUNT(*) FROM Inspection WHERE client_id = ? AND status = 'Scheduled') as scheduledInspections,
                (SELECT COUNT(*) FROM Transaction WHERE client_id = ?) as myTransactions,
                (SELECT COUNT(*) FROM Feedback WHERE client_id = ?) as myFeedback,
                (SELECT COUNT(*) FROM Listing WHERE listing_status = 'Active') as availableProperties
        `, [clientId, clientId, clientId]);

        res.json(results[0]);
    } catch (error) {
        console.error('Client dashboard error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// BROWSE AVAILABLE PROPERTIES
// =============================================

router.get('/properties', async (req, res) => {
    try {
        const { type, minPrice, maxPrice, area, bedrooms, property_for } = req.query;

        let query = `
            SELECT l.listing_id, l.listing_price, l.description as listing_description, l.featured, l.views_count,
                   p.property_id, p.title, p.description, p.price, p.area_sqft, p.bedrooms, p.bathrooms, 
                   p.year_built, p.property_for, p.image_url,
                   pt.type_name, loc.address, loc.area, loc.city,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name, a.phone as agent_phone
            FROM Listing l
            JOIN Property p ON l.property_id = p.property_id
            JOIN Property_Type pt ON p.type_id = pt.type_id
            JOIN Location loc ON p.location_id = loc.location_id
            JOIN Agent a ON l.agent_id = a.agent_id
            WHERE l.listing_status = 'Active' AND p.status = 'Available'
        `;

        const params = [];

        if (type) {
            query += ' AND pt.type_id = ?';
            params.push(type);
        }
        if (minPrice) {
            query += ' AND l.listing_price >= ?';
            params.push(minPrice);
        }
        if (maxPrice) {
            query += ' AND l.listing_price <= ?';
            params.push(maxPrice);
        }
        if (area) {
            query += ' AND loc.area LIKE ?';
            params.push(`%${area}%`);
        }
        if (bedrooms) {
            query += ' AND p.bedrooms >= ?';
            params.push(bedrooms);
        }
        if (property_for) {
            query += ' AND p.property_for = ?';
            params.push(property_for);
        }

        query += ' ORDER BY l.featured DESC, l.created_at DESC';

        const [properties] = await pool.query(query, params);
        res.json(properties);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/properties/:id', async (req, res) => {
    try {
        const [properties] = await pool.query(`
            SELECT l.listing_id, l.listing_price, l.description as listing_description, l.featured,
                   p.*, pt.type_name, loc.*, 
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name, a.phone as agent_phone, a.email as agent_email
            FROM Listing l
            JOIN Property p ON l.property_id = p.property_id
            JOIN Property_Type pt ON p.type_id = pt.type_id
            JOIN Location loc ON p.location_id = loc.location_id
            JOIN Agent a ON l.agent_id = a.agent_id
            WHERE l.listing_id = ?
        `, [req.params.id]);

        if (properties.length === 0) {
            return res.status(404).json({ error: 'Property not found' });
        }

        // Increment view count
        await pool.query('UPDATE Listing SET views_count = views_count + 1 WHERE listing_id = ?', [req.params.id]);

        res.json(properties[0]);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// BOOK INSPECTIONS
// =============================================

router.get('/inspections', async (req, res) => {
    try {
        const [inspections] = await pool.query(`
            SELECT i.*, p.title as property_title, loc.address,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name
            FROM Inspection i
            JOIN Listing l ON i.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            JOIN Location loc ON p.location_id = loc.location_id
            JOIN Agent a ON l.agent_id = a.agent_id
            WHERE i.client_id = ?
            ORDER BY i.inspection_date DESC
        `, [req.user.id]);
        res.json(inspections);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/inspections', async (req, res) => {
    try {
        const { listing_id, inspection_date, inspection_time, notes } = req.body;

        // Check if listing exists and is active
        const [listing] = await pool.query(
            "SELECT listing_id FROM Listing WHERE listing_id = ? AND listing_status = 'Active'",
            [listing_id]
        );
        if (listing.length === 0) {
            return res.status(400).json({ error: 'Listing not available' });
        }

        const [result] = await pool.query(
            `INSERT INTO Inspection (listing_id, client_id, inspection_date, inspection_time, status, notes)
             VALUES (?, ?, ?, ?, 'Scheduled', ?)`,
            [listing_id, req.user.id, inspection_date, inspection_time, notes]
        );
        res.status(201).json({ success: true, id: result.insertId, message: 'Inspection booked successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/inspections/:id/cancel', async (req, res) => {
    try {
        const [check] = await pool.query(
            'SELECT client_id, status FROM Inspection WHERE inspection_id = ?',
            [req.params.id]
        );

        if (check.length === 0 || check[0].client_id !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized' });
        }

        if (check[0].status !== 'Scheduled') {
            return res.status(400).json({ error: 'Can only cancel scheduled inspections' });
        }

        await pool.query(
            "UPDATE Inspection SET status = 'Cancelled' WHERE inspection_id = ?",
            [req.params.id]
        );
        res.json({ success: true, message: 'Inspection cancelled' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// SUBMIT FEEDBACK
// =============================================

router.get('/feedback', async (req, res) => {
    try {
        const [feedback] = await pool.query(`
            SELECT f.*, p.title as property_title
            FROM Feedback f
            JOIN Listing l ON f.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            WHERE f.client_id = ?
            ORDER BY f.feedback_date DESC
        `, [req.user.id]);
        res.json(feedback);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/feedback', async (req, res) => {
    try {
        const { listing_id, rating, comment } = req.body;

        if (!rating || rating < 1 || rating > 5) {
            return res.status(400).json({ error: 'Rating must be between 1 and 5' });
        }

        // Check if already submitted feedback for this listing
        const [existing] = await pool.query(
            'SELECT feedback_id FROM Feedback WHERE listing_id = ? AND client_id = ?',
            [listing_id, req.user.id]
        );
        if (existing.length > 0) {
            return res.status(400).json({ error: 'You have already submitted feedback for this property' });
        }

        const [result] = await pool.query(
            `INSERT INTO Feedback (listing_id, client_id, rating, comment, feedback_date)
             VALUES (?, ?, ?, ?, CURDATE())`,
            [listing_id, req.user.id, rating, comment]
        );
        res.status(201).json({ success: true, id: result.insertId, message: 'Feedback submitted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// VIEW TRANSACTIONS
// =============================================

router.get('/transactions', async (req, res) => {
    try {
        const [transactions] = await pool.query(`
            SELECT t.*, p.title as property_title, loc.address
            FROM Transaction t
            JOIN Listing l ON t.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            JOIN Location loc ON p.location_id = loc.location_id
            WHERE t.client_id = ?
            ORDER BY t.transaction_date DESC
        `, [req.user.id]);
        res.json(transactions);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/transactions/:id', async (req, res) => {
    try {
        // Fetch Transaction AND Payments in a single JOINed query
        const [rows] = await pool.query(`
            SELECT t.*, p.title as property_title, loc.address,
                   CONCAT(a.first_name, ' ', a.last_name) as agent_name,
                   pay.payment_id, pay.amount as payment_amount, pay.payment_date, pay.payment_method, 
                   pay.payment_status, pay.reference_number, pay.notes as payment_notes
            FROM Transaction t
            JOIN Listing l ON t.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            JOIN Location loc ON p.location_id = loc.location_id
            JOIN Agent a ON l.agent_id = a.agent_id
            LEFT JOIN Payment pay ON t.transaction_id = pay.transaction_id
            WHERE t.transaction_id = ? AND t.client_id = ?
            ORDER BY pay.payment_date
        `, [req.params.id, req.user.id]);

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Transaction not found' });
        }

        // Process rows to reconstruct the transaction object with a 'payments' array
        const transaction = {
            transaction_id: rows[0].transaction_id,
            listing_id: rows[0].listing_id,
            client_id: rows[0].client_id,
            transaction_type: rows[0].transaction_type,
            transaction_date: rows[0].transaction_date,
            amount: rows[0].amount,
            commission: rows[0].commission,
            status: rows[0].status,
            notes: rows[0].notes,
            created_at: rows[0].created_at,
            updated_at: rows[0].updated_at,
            property_title: rows[0].property_title,
            address: rows[0].address,
            agent_name: rows[0].agent_name,
            payments: []
        };

        // Populate payments array if payments exist
        rows.forEach(row => {
            if (row.payment_id) {
                transaction.payments.push({
                    payment_id: row.payment_id,
                    transaction_id: row.transaction_id,
                    payment_date: row.payment_date,
                    amount: row.payment_amount,
                    payment_method: row.payment_method,
                    payment_status: row.payment_status,
                    reference_number: row.reference_number,
                    notes: row.payment_notes
                });
            }
        });

        res.json(transaction);
    } catch (error) {
        console.error('Error fetching transaction details:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// HELPER DATA
// =============================================

router.get('/property-types', async (req, res) => {
    try {
        const [types] = await pool.query('SELECT * FROM Property_Type ORDER BY type_name');
        res.json(types);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/locations', async (req, res) => {
    try {
        const [locations] = await pool.query('SELECT DISTINCT area FROM Location ORDER BY area');
        res.json(locations);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;
