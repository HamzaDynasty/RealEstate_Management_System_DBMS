const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { verifyToken, authorize } = require('../middleware/auth');

// Apply authentication to all agent routes
router.use(verifyToken);
router.use(authorize('agent', 'admin'));

// =============================================
// AGENT DASHBOARD
// =============================================

router.get('/dashboard', async (req, res) => {
    try {
        const agentId = req.user.id;

        const [results] = await pool.query(`
            SELECT 
                (SELECT COUNT(*) FROM Property WHERE agent_id = ?) as myProperties,
                (SELECT COUNT(*) FROM Listing WHERE agent_id = ? AND listing_status = 'Active') as activeListings,
                (SELECT COUNT(*) FROM Inspection i 
                 JOIN Listing l ON i.listing_id = l.listing_id 
                 WHERE l.agent_id = ? AND i.status = 'Scheduled') as scheduledInspections,
                (SELECT COUNT(*) FROM Transaction t 
                 JOIN Listing l ON t.listing_id = l.listing_id 
                 WHERE l.agent_id = ? AND t.status = 'Completed') as completedDeals,
                (SELECT COALESCE(SUM(t.commission), 0) FROM Transaction t 
                 JOIN Listing l ON t.listing_id = l.listing_id 
                 WHERE l.agent_id = ? AND t.status = 'Completed') as totalCommission
        `, [agentId, agentId, agentId, agentId, agentId]);

        res.json(results[0]);
    } catch (error) {
        console.error('Agent dashboard error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// AGENT'S PROPERTIES
// =============================================

router.get('/properties', async (req, res) => {
    try {
        const [properties] = await pool.query(`
            SELECT p.*, pt.type_name, l.address, l.area, l.city
            FROM Property p
            JOIN Property_Type pt ON p.type_id = pt.type_id
            JOIN Location l ON p.location_id = l.location_id
            WHERE p.agent_id = ?
            ORDER BY p.created_at DESC
        `, [req.user.id]);
        res.json(properties);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/properties', async (req, res) => {
    try {
        const { type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for } = req.body;
        const [result] = await pool.query(
            `INSERT INTO Property (agent_id, type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [req.user.id, type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status || 'Available', property_for || 'Sale']
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/properties/:id', async (req, res) => {
    try {
        // Verify ownership
        const [check] = await pool.query('SELECT agent_id FROM Property WHERE property_id = ?', [req.params.id]);
        if (check.length === 0 || check[0].agent_id !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized to update this property' });
        }

        const { type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for } = req.body;
        await pool.query(
            `UPDATE Property SET type_id = ?, location_id = ?, title = ?, description = ?, price = ?, 
             area_sqft = ?, bedrooms = ?, bathrooms = ?, year_built = ?, status = ?, property_for = ? WHERE property_id = ?`,
            [type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for, req.params.id]
        );
        res.json({ success: true, message: 'Property updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.delete('/properties/:id', async (req, res) => {
    try {
        const [check] = await pool.query('SELECT agent_id FROM Property WHERE property_id = ?', [req.params.id]);
        if (check.length === 0 || check[0].agent_id !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized to delete this property' });
        }
        await pool.query('DELETE FROM Property WHERE property_id = ?', [req.params.id]);
        res.json({ success: true, message: 'Property deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// AGENT'S LISTINGS
// =============================================

router.get('/listings', async (req, res) => {
    try {
        const [listings] = await pool.query(`
            SELECT l.*, p.title as property_title, p.price as property_price
            FROM Listing l
            JOIN Property p ON l.property_id = p.property_id
            WHERE l.agent_id = ?
            ORDER BY l.created_at DESC
        `, [req.user.id]);
        res.json(listings);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/listings', async (req, res) => {
    try {
        const { property_id, listing_date, expiry_date, listing_price, description, featured } = req.body;

        // Verify property ownership
        const [check] = await pool.query('SELECT agent_id FROM Property WHERE property_id = ?', [property_id]);
        if (check.length === 0 || check[0].agent_id !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized to list this property' });
        }

        const [result] = await pool.query(
            `INSERT INTO Listing (property_id, agent_id, listing_date, expiry_date, listing_price, description, featured)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [property_id, req.user.id, listing_date || new Date(), expiry_date, listing_price, description, featured || false]
        );
        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/listings/:id', async (req, res) => {
    try {
        const [check] = await pool.query('SELECT agent_id FROM Listing WHERE listing_id = ?', [req.params.id]);
        if (check.length === 0 || check[0].agent_id !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized to update this listing' });
        }

        const { listing_price, listing_status, description, featured, expiry_date } = req.body;
        await pool.query(
            'UPDATE Listing SET listing_price = ?, listing_status = ?, description = ?, featured = ?, expiry_date = ? WHERE listing_id = ?',
            [listing_price, listing_status, description, featured, expiry_date, req.params.id]
        );
        res.json({ success: true, message: 'Listing updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// AGENT'S INSPECTIONS
// =============================================

router.get('/inspections', async (req, res) => {
    try {
        const [inspections] = await pool.query(`
            SELECT i.*, CONCAT(c.first_name, ' ', c.last_name) as client_name,
                   c.phone as client_phone, p.title as property_title
            FROM Inspection i
            JOIN Client c ON i.client_id = c.client_id
            JOIN Listing l ON i.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            WHERE l.agent_id = ?
            ORDER BY i.inspection_date DESC
        `, [req.user.id]);
        res.json(inspections);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.put('/inspections/:id', async (req, res) => {
    try {
        const { status, agent_feedback } = req.body;

        // Verify access
        const [check] = await pool.query(`
            SELECT l.agent_id FROM Inspection i
            JOIN Listing l ON i.listing_id = l.listing_id
            WHERE i.inspection_id = ?
        `, [req.params.id]);

        if (check.length === 0 || check[0].agent_id !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized' });
        }

        await pool.query(
            'UPDATE Inspection SET status = ?, agent_feedback = ? WHERE inspection_id = ?',
            [status, agent_feedback, req.params.id]
        );
        res.json({ success: true, message: 'Inspection updated' });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// AGENT'S FEEDBACK (VIEW)
// =============================================

router.get('/feedback', async (req, res) => {
    try {
        const [feedback] = await pool.query(`
            SELECT f.*, CONCAT(c.first_name, ' ', c.last_name) as client_name,
                   p.title as property_title
            FROM Feedback f
            JOIN Client c ON f.client_id = c.client_id
            JOIN Listing l ON f.listing_id = l.listing_id
            JOIN Property p ON l.property_id = p.property_id
            WHERE l.agent_id = ?
            ORDER BY f.feedback_date DESC
        `, [req.user.id]);
        res.json(feedback);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// =============================================
// HELPER DATA
// =============================================

router.get('/property-types', async (req, res) => {
    try {
        const [types] = await pool.query('SELECT * FROM Property_Type ORDER BY type_name');
        res.json(types);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/locations', async (req, res) => {
    try {
        const [locations] = await pool.query('SELECT * FROM Location ORDER BY address');
        res.json(locations);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

router.get('/clients', async (req, res) => {
    try {
        const [clients] = await pool.query('SELECT client_id, first_name, last_name, email, phone FROM Client WHERE is_active = TRUE');
        res.json(clients);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;
