const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const pool = require('../config/db');
const { generateToken } = require('../middleware/auth');

// =============================================
// ADMIN (AGENCY) AUTHENTICATION
// =============================================

// Admin Login
router.post('/admin/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const [agencies] = await pool.query(
            'SELECT * FROM Agency WHERE email = ? AND is_active = TRUE',
            [email]
        );

        if (agencies.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const agency = agencies[0];
        const isValidPassword = await bcrypt.compare(password, agency.password);

        if (!isValidPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = generateToken({
            id: agency.agency_id,
            email: agency.email,
            name: agency.agency_name
        }, 'admin');

        res.json({
            success: true,
            token,
            user: {
                id: agency.agency_id,
                name: agency.agency_name,
                email: agency.email,
                role: 'admin'
            }
        });
    } catch (error) {
        console.error('Admin login error:', error);
        res.status(500).json({ error: 'Server error during login' });
    }
});

// Admin Signup
router.post('/admin/signup', async (req, res) => {
    try {
        const { agency_name, email, password, phone, address, license_number } = req.body;

        if (!agency_name || !email || !password) {
            return res.status(400).json({ error: 'Agency name, email, and password are required' });
        }

        // Check if email exists
        const [existing] = await pool.query('SELECT agency_id FROM Agency WHERE email = ?', [email]);
        if (existing.length > 0) {
            return res.status(409).json({ error: 'Email already registered' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const [result] = await pool.query(
            `INSERT INTO Agency (agency_name, email, password, phone, address, license_number) 
             VALUES (?, ?, ?, ?, ?, ?)`,
            [agency_name, email, hashedPassword, phone, address, license_number]
        );

        const token = generateToken({
            id: result.insertId,
            email: email,
            name: agency_name
        }, 'admin');

        res.status(201).json({
            success: true,
            token,
            user: {
                id: result.insertId,
                name: agency_name,
                email: email,
                role: 'admin'
            }
        });
    } catch (error) {
        console.error('Admin signup error:', error);
        res.status(500).json({ error: 'Server error during signup' });
    }
});

// =============================================
// AGENT AUTHENTICATION
// =============================================

// Agent Login
router.post('/agent/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const [agents] = await pool.query(
            `SELECT a.*, ag.agency_name FROM Agent a 
             JOIN Agency ag ON a.agency_id = ag.agency_id 
             WHERE a.email = ? AND a.is_active = TRUE`,
            [email]
        );

        if (agents.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const agent = agents[0];
        const isValidPassword = await bcrypt.compare(password, agent.password);

        if (!isValidPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = generateToken({
            id: agent.agent_id,
            email: agent.email,
            name: `${agent.first_name} ${agent.last_name}`,
            agency_id: agent.agency_id
        }, 'agent');

        res.json({
            success: true,
            token,
            user: {
                id: agent.agent_id,
                name: `${agent.first_name} ${agent.last_name}`,
                email: agent.email,
                agency: agent.agency_name,
                agency_id: agent.agency_id,
                role: 'agent'
            }
        });
    } catch (error) {
        console.error('Agent login error:', error);
        res.status(500).json({ error: 'Server error during login' });
    }
});

// Agent Signup
router.post('/agent/signup', async (req, res) => {
    try {
        const { first_name, last_name, email, password, phone, agency_id, license_number } = req.body;

        if (!first_name || !last_name || !email || !password || !agency_id) {
            return res.status(400).json({ error: 'First name, last name, email, password, and agency ID are required' });
        }

        // Check if email exists
        const [existing] = await pool.query('SELECT agent_id FROM Agent WHERE email = ?', [email]);
        if (existing.length > 0) {
            return res.status(409).json({ error: 'Email already registered' });
        }

        // Check if agency exists
        const [agency] = await pool.query('SELECT agency_id, agency_name FROM Agency WHERE agency_id = ?', [agency_id]);
        if (agency.length === 0) {
            return res.status(400).json({ error: 'Invalid agency ID' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const [result] = await pool.query(
            `INSERT INTO Agent (agency_id, first_name, last_name, email, password, phone, license_number, hire_date) 
             VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE())`,
            [agency_id, first_name, last_name, email, hashedPassword, phone, license_number]
        );

        const token = generateToken({
            id: result.insertId,
            email: email,
            name: `${first_name} ${last_name}`,
            agency_id: agency_id
        }, 'agent');

        res.status(201).json({
            success: true,
            token,
            user: {
                id: result.insertId,
                name: `${first_name} ${last_name}`,
                email: email,
                agency: agency[0].agency_name,
                agency_id: agency_id,
                role: 'agent'
            }
        });
    } catch (error) {
        console.error('Agent signup error:', error);
        res.status(500).json({ error: 'Server error during signup' });
    }
});

// =============================================
// CLIENT AUTHENTICATION
// =============================================

// Client Login
router.post('/client/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const [clients] = await pool.query(
            'SELECT * FROM Client WHERE email = ? AND is_active = TRUE',
            [email]
        );

        if (clients.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const client = clients[0];
        const isValidPassword = await bcrypt.compare(password, client.password);

        if (!isValidPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = generateToken({
            id: client.client_id,
            email: client.email,
            name: `${client.first_name} ${client.last_name}`
        }, 'client');

        res.json({
            success: true,
            token,
            user: {
                id: client.client_id,
                name: `${client.first_name} ${client.last_name}`,
                email: client.email,
                client_type: client.client_type,
                role: 'client'
            }
        });
    } catch (error) {
        console.error('Client login error:', error);
        res.status(500).json({ error: 'Server error during login' });
    }
});

// Client Signup
router.post('/client/signup', async (req, res) => {
    try {
        const { first_name, last_name, email, password, phone, address, cnic, client_type } = req.body;

        if (!first_name || !last_name || !email || !password) {
            return res.status(400).json({ error: 'First name, last name, email, and password are required' });
        }

        // Check if email exists
        const [existing] = await pool.query('SELECT client_id FROM Client WHERE email = ?', [email]);
        if (existing.length > 0) {
            return res.status(409).json({ error: 'Email already registered' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const [result] = await pool.query(
            `INSERT INTO Client (first_name, last_name, email, password, phone, address, cnic, client_type) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [first_name, last_name, email, hashedPassword, phone, address, cnic, client_type || 'Buyer']
        );

        const token = generateToken({
            id: result.insertId,
            email: email,
            name: `${first_name} ${last_name}`
        }, 'client');

        res.status(201).json({
            success: true,
            token,
            user: {
                id: result.insertId,
                name: `${first_name} ${last_name}`,
                email: email,
                client_type: client_type || 'Buyer',
                role: 'client'
            }
        });
    } catch (error) {
        console.error('Client signup error:', error);
        res.status(500).json({ error: 'Server error during signup' });
    }
});

// =============================================
// TOKEN VERIFICATION
// =============================================

router.get('/verify', require('../middleware/auth').verifyToken, (req, res) => {
    res.json({
        valid: true,
        user: req.user
    });
});

// Get all agencies (for agent signup dropdown)
router.get('/agencies', async (req, res) => {
    try {
        const [agencies] = await pool.query(
            'SELECT agency_id, agency_name FROM Agency WHERE is_active = TRUE'
        );
        res.json(agencies);
    } catch (error) {
        console.error('Error fetching agencies:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;
