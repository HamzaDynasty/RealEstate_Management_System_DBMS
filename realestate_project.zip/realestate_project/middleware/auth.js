const jwt = require('jsonwebtoken');
require('dotenv').config();

const JWT_SECRET = process.env.JWT_SECRET || 'default_secret_key';

// Generate JWT token
const generateToken = (user, role) => {
    return jwt.sign(
        {
            id: user.id,
            email: user.email,
            role: role,
            name: user.name
        },
        JWT_SECRET,
        { expiresIn: '24h' }
    );
};

// Verify JWT token
const verifyToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access denied. No token provided.' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(403).json({ error: 'Invalid or expired token.' });
    }
};

// Role-based authorization middleware
const authorize = (...allowedRoles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'User not authenticated.' });
        }

        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({
                error: 'Access denied. Insufficient privileges.',
                required: allowedRoles,
                current: req.user.role
            });
        }

        next();
    };
};

// Admin only middleware
const adminOnly = authorize('admin');

// Agent or Admin middleware
const agentOrAdmin = authorize('admin', 'agent');

// Any authenticated user
const authenticated = authorize('admin', 'agent', 'client');

module.exports = {
    generateToken,
    verifyToken,
    authorize,
    adminOnly,
    agentOrAdmin,
    authenticated
};
