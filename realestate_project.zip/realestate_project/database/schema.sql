
-- Real Estate Management System Database Schema
-- =============================================

-- Create and use database
CREATE DATABASE IF NOT EXISTS real_estate_db;
USE real_estate_db;

-- Drop tables if they exist (for clean setup)
DROP TABLE IF EXISTS Feedback;
DROP TABLE IF EXISTS Inspection;
DROP TABLE IF EXISTS Contract;
DROP TABLE IF EXISTS Payment;
DROP TABLE IF EXISTS Transaction;
DROP TABLE IF EXISTS Listing;
DROP TABLE IF EXISTS Property;
DROP TABLE IF EXISTS Location;
DROP TABLE IF EXISTS Property_Type;
DROP TABLE IF EXISTS Client;
DROP TABLE IF EXISTS Agent;
DROP TABLE IF EXISTS Agency;

-- =============================================
-- Agency Table (Admin/Company)
-- =============================================
CREATE TABLE Agency (
    agency_id INT PRIMARY KEY AUTO_INCREMENT,
    agency_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    license_number VARCHAR(50) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- =============================================
-- Agent Table
-- =============================================
CREATE TABLE Agent (
    agent_id INT PRIMARY KEY AUTO_INCREMENT,
    agency_id INT NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    license_number VARCHAR(50) UNIQUE,
    commission_rate DECIMAL(5,2) DEFAULT 2.50,
    hire_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    CONSTRAINT fk_agent_agency FOREIGN KEY (agency_id) REFERENCES Agency(agency_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- Client Table
-- =============================================
CREATE TABLE Client (
    client_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    cnic VARCHAR(15) UNIQUE,
    client_type ENUM('Buyer', 'Seller', 'Renter', 'Landlord') DEFAULT 'Buyer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- =============================================
-- Property_Type Table
-- =============================================
CREATE TABLE Property_Type (
    type_id INT PRIMARY KEY AUTO_INCREMENT,
    type_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- Location Table
-- =============================================
CREATE TABLE Location (
    location_id INT PRIMARY KEY AUTO_INCREMENT,
    address VARCHAR(255) NOT NULL,
    city VARCHAR(50) DEFAULT 'Islamabad',
    area VARCHAR(100),
    postal_code VARCHAR(10),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- Property Table
-- =============================================
CREATE TABLE Property (
    property_id INT PRIMARY KEY AUTO_INCREMENT,
    agent_id INT NOT NULL,
    type_id INT NOT NULL,
    location_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    price DECIMAL(15, 2) NOT NULL,
    area_sqft INT,
    bedrooms INT DEFAULT 0,
    bathrooms INT DEFAULT 0,
    year_built INT,
    status ENUM('Available', 'Sold', 'Rented', 'Pending', 'Off-Market') DEFAULT 'Available',
    property_for ENUM('Sale', 'Rent') DEFAULT 'Sale',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_property_agent FOREIGN KEY (agent_id) REFERENCES Agent(agent_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_property_type FOREIGN KEY (type_id) REFERENCES Property_Type(type_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_property_location FOREIGN KEY (location_id) REFERENCES Location(location_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_price CHECK (price > 0),
    CONSTRAINT chk_area CHECK (area_sqft > 0),
    CONSTRAINT chk_bedrooms CHECK (bedrooms >= 0),
    CONSTRAINT chk_bathrooms CHECK (bathrooms >= 0)
);

-- =============================================
-- Listing Table
-- =============================================
CREATE TABLE Listing (
    listing_id INT PRIMARY KEY AUTO_INCREMENT,
    property_id INT NOT NULL,
    agent_id INT NOT NULL,
    listing_date DATE NOT NULL,
    expiry_date DATE,
    listing_price DECIMAL(15, 2) NOT NULL,
    listing_status ENUM('Active', 'Inactive', 'Sold', 'Expired') DEFAULT 'Active',
    description TEXT,
    featured BOOLEAN DEFAULT FALSE,
    views_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_listing_property FOREIGN KEY (property_id) REFERENCES Property(property_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_listing_agent FOREIGN KEY (agent_id) REFERENCES Agent(agent_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_listing_price CHECK (listing_price > 0)
);

-- =============================================
-- Transaction Tableagency
-- =============================================
CREATE TABLE Transaction (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    listing_id INT NOT NULL,
    client_id INT NOT NULL,
    transaction_type ENUM('Sale', 'Rent') NOT NULL,
    transaction_date DATE NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    commission DECIMAL(15, 2),
    status ENUM('Pending', 'Completed', 'Cancelled') DEFAULT 'Pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_transaction_listing FOREIGN KEY (listing_id) REFERENCES Listing(listing_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_transaction_client FOREIGN KEY (client_id) REFERENCES Client(client_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_amount CHECK (amount > 0)
);

-- =============================================
-- Payment Table
-- =============================================
CREATE TABLE Payment (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_id INT NOT NULL,
    payment_date DATE NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    payment_method ENUM('Cash', 'Bank Transfer', 'Cheque', 'Online') DEFAULT 'Bank Transfer',
    payment_status ENUM('Pending', 'Completed', 'Failed', 'Refunded') DEFAULT 'Pending',
    reference_number VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_transaction FOREIGN KEY (transaction_id) REFERENCES Transaction(transaction_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_payment_amount CHECK (amount > 0)
);

-- =============================================
-- Contract Table
-- =============================================
CREATE TABLE Contract (
    contract_id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_id INT NOT NULL,
    contract_date DATE NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    terms TEXT,
    contract_type ENUM('Sale', 'Rental', 'Lease') NOT NULL,
    status ENUM('Draft', 'Active', 'Completed', 'Terminated') DEFAULT 'Draft',
    document_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_contract_transaction FOREIGN KEY (transaction_id) REFERENCES Transaction(transaction_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- Inspection Table
-- =============================================
CREATE TABLE Inspection (
    inspection_id INT PRIMARY KEY AUTO_INCREMENT,
    listing_id INT NOT NULL,
    client_id INT NOT NULL,
    inspection_date DATE NOT NULL,
    inspection_time TIME NOT NULL,
    status ENUM('Scheduled', 'Completed', 'Cancelled', 'No-Show') DEFAULT 'Scheduled',
    notes TEXT,
    agent_feedback TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_inspection_listing FOREIGN KEY (listing_id) REFERENCES Listing(listing_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_inspection_client FOREIGN KEY (client_id) REFERENCES Client(client_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- Feedback Table
-- =============================================
CREATE TABLE Feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    listing_id INT NOT NULL,
    client_id INT NOT NULL,
    rating INT NOT NULL,
    comment TEXT,
    feedback_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_feedback_listing FOREIGN KEY (listing_id) REFERENCES Listing(listing_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_feedback_client FOREIGN KEY (client_id) REFERENCES Client(client_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_rating CHECK (rating >= 1 AND rating <= 5)
);

-- =============================================
-- Create indexes for better performance
-- =============================================
CREATE INDEX idx_property_status ON Property(status);
CREATE INDEX idx_property_price ON Property(price);
CREATE INDEX idx_listing_status ON Listing(listing_status);
CREATE INDEX idx_transaction_status ON Transaction(status);
CREATE INDEX idx_agent_agency ON Agent(agency_id);
CREATE INDEX idx_property_agent ON Property(agent_id);
