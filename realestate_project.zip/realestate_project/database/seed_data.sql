-- =============================================
-- Real Estate Management System - Extended Sample Data
-- Using Pakistani Names, Locations, and PKR Currency
-- =============================================

USE real_estate_db;

-- Clear existing data (in reverse order due to foreign keys)
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE Feedback;
TRUNCATE TABLE Inspection;
TRUNCATE TABLE Contract;
TRUNCATE TABLE Payment;
TRUNCATE TABLE Transaction;
TRUNCATE TABLE Listing;
TRUNCATE TABLE Property;
TRUNCATE TABLE Location;
TRUNCATE TABLE Property_Type;
TRUNCATE TABLE Client;
TRUNCATE TABLE Agent;
TRUNCATE TABLE Agency;
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================
-- Insert Agencies (3 agencies)
-- =============================================
INSERT INTO Agency (agency_name, email, password, phone, address, license_number) VALUES
('Prime Properties Islamabad', 'admin@primeproperties.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-51-1234567', 'F-7 Markaz, Islamabad', 'REA-2024-001'),
('Elite Realty Pakistan', 'admin@eliterealty.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-51-2345678', 'Blue Area, Islamabad', 'REA-2024-002'),
('Capital Estate Advisors', 'admin@capitalestate.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-51-3456789', 'F-10 Markaz, Islamabad', 'REA-2024-003');

-- =============================================
-- Insert Property Types (10 types)
-- =============================================
INSERT INTO Property_Type (type_name, description) VALUES
('House', 'Independent residential house with yard'),
('Villa', 'Luxury standalone residential property'),
('Apartment', 'Residential unit in multi-story building'),
('Plot', 'Empty land for construction'),
('Commercial', 'Office or retail space'),
('Penthouse', 'Luxury top-floor apartment'),
('Farmhouse', 'Rural residential property with land'),
('Studio', 'Single room apartment with kitchenette'),
('Duplex', 'Two-floor connected residential unit'),
('Townhouse', 'Row house with shared walls');

-- =============================================
-- Insert Locations (30 specified addresses)
-- =============================================
INSERT INTO Location (address, city, area, postal_code) VALUES
('House 14, F-7 Markaz', 'Islamabad', 'F-7 Markaz', '44000'),
('Plot 28, G-6 Sector', 'Islamabad', 'G-6 Sector', '44000'),
('Office 305, Blue Area', 'Islamabad', 'Blue Area', '44000'),
('House 45, Street 12, I-8/3', 'Islamabad', 'I-8/3', '44000'),
('Shop 15, F-10 Markaz', 'Islamabad', 'F-10 Markaz', '44000'),
('Villa 22, Bahria Enclave', 'Islamabad', 'Bahria Enclave', '44000'),
('House 88, DHA Phase II', 'Islamabad', 'DHA Phase II', '44000'),
('Plot 55, G-13', 'Islamabad', 'G-13', '44000'),
('Apartment 12, E-11/4', 'Islamabad', 'E-11/4', '44000'),
('Shop 8, F-6 Super Market', 'Islamabad', 'F-6 Super Market', '44000'),
('Office 201, Giga Mall, DHA', 'Islamabad', 'Giga Mall DHA', '44000'),
('Shop 45, Centaurus Mall', 'Islamabad', 'Centaurus Mall', '44000'),
('Plot near Pakistan Monument, Shakarparian', 'Islamabad', 'Shakarparian', '44000'),
('Warehouse 5, I-9 Industrial Area', 'Islamabad', 'I-9 Industrial', '44000'),
('Villa 3, G-5 Diplomatic Enclave', 'Islamabad', 'G-5 Diplomatic', '44000'),
('Villa overlooking Rawal Lake View Point', 'Islamabad', 'Rawal Lake', '44000'),
('House 77, H-9 Sector', 'Islamabad', 'H-9 Sector', '44000'),
('House 33, Street 5, F-11/2', 'Islamabad', 'F-11/2', '44000'),
('Apartment 8B, G-10/1', 'Islamabad', 'G-10/1', '44000'),
('House 112, PWD Housing Society', 'Islamabad', 'PWD Housing', '44000'),
('Farmhouse 4, Chak Shahzad', 'Islamabad', 'Chak Shahzad', '44000'),
('Villa 18, Bani Gala', 'Islamabad', 'Bani Gala', '44000'),
('House 66, Bahria Town Phase 4', 'Rawalpindi', 'Bahria Phase 4', '46000'),
('Apartment near NUST, H-12', 'Islamabad', 'NUST H-12', '44000'),
('House 29, G-9/4', 'Islamabad', 'G-9/4', '44000'),
('Plot near Margalla Hills Trail 5', 'Islamabad', 'Margalla Hills', '44000'),
('House 44, I-10/2', 'Islamabad', 'I-10/2', '44000'),
('Office near Parliament House Area', 'Islamabad', 'Parliament House', '44000'),
('House 56, G-8/1', 'Islamabad', 'G-8/1', '44000'),
('Office 102, F-5 Red Zone', 'Islamabad', 'F-5 Red Zone', '44000');

-- =============================================
-- Insert Agents (10 agents with specified names)
-- =============================================
INSERT INTO Agent (agency_id, first_name, last_name, email, password, phone, license_number, commission_rate, hire_date) VALUES
(1, 'Ahmed', 'Raza', 'ahmed.raza@primeproperties.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-300-1111111', 'AGT-2024-001', 2.50, '2023-01-15'),
(1, 'Hania', 'Malik', 'hania.malik@primeproperties.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-300-2222222', 'AGT-2024-002', 2.75, '2023-03-20'),
(1, 'Bilal', 'Ahmed', 'bilal.ahmed@primeproperties.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-300-3333333', 'AGT-2024-003', 2.50, '2023-06-10'),
(2, 'Ayesha', 'Siddiqui', 'ayesha.siddiqui@eliterealty.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-300-4444444', 'AGT-2024-004', 3.00, '2023-02-01'),
(2, 'Umar', 'Farooq', 'umar.farooq@eliterealty.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-300-5555555', 'AGT-2024-005', 2.50, '2023-05-15'),
(2, 'Rimsha', 'Khan', 'rimsha.khan@eliterealty.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-300-6666666', 'AGT-2024-006', 2.75, '2023-07-01'),
(3, 'Hamza', 'Ali', 'hamza.ali@capitalestate.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-300-7777777', 'AGT-2024-007', 2.50, '2023-04-10'),
(3, 'Maryam', 'Javed', 'maryam.javed@capitalestate.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-300-8888888', 'AGT-2024-008', 3.00, '2023-08-15'),
(3, 'Shahzaib', 'Aslam', 'shahzaib.aslam@capitalestate.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-300-9999999', 'AGT-2024-009', 2.50, '2023-09-01'),
(1, 'Hafsa', 'Tariq', 'hafsa.tariq@primeproperties.pk', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-301-1111111', 'AGT-2024-010', 2.75, '2023-10-01');

-- =============================================
-- Insert Clients (15 clients with specified names)
-- =============================================
INSERT INTO Client (first_name, last_name, email, password, phone, address, cnic, client_type) VALUES
('Daniyal', 'Sheikh', 'daniyal.sheikh@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-321-1111111', 'House 45, G-9, Islamabad', '35201-1111111-1', 'Buyer'),
('Noor', 'Fatima', 'noor.fatima@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-321-2222222', 'Apartment 12, F-10, Islamabad', '35201-2222222-2', 'Buyer'),
('Saad', 'Mehmood', 'saad.mehmood@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-321-3333333', 'Villa 8, DHA Phase 2, Islamabad', '35201-3333333-3', 'Seller'),
('Laiba', 'Anwar', 'laiba.anwar@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-321-4444444', 'House 22, I-8, Islamabad', '35201-4444444-4', 'Renter'),
('Zain-ul', 'Abidin', 'zain.abidin@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-321-5555555', 'Flat 5, Blue Area, Islamabad', '35201-5555555-5', 'Buyer'),
('Mehwish', 'Akram', 'mehwish.akram@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-321-6666666', 'House 99, G-11, Islamabad', '35201-6666666-6', 'Landlord'),
('Ali', 'Shan', 'ali.shan@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-321-7777777', 'Apartment 3, F-7, Islamabad', '35201-7777777-7', 'Buyer'),
('Saba', 'Qureshi', 'saba.qureshi@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-321-8888888', 'House 15, E-11, Islamabad', '35201-8888888-8', 'Seller'),
('Salman', 'Yousaf', 'salman.yousaf@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-321-9999999', 'Villa 4, Bahria Enclave', '35201-9999999-9', 'Buyer'),
('Emaan', 'Feroze', 'emaan.feroze@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-322-1111111', 'House 78, F-8, Islamabad', '35202-1111111-1', 'Renter'),
('Fahad', 'Iqbal', 'fahad.iqbal@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-322-2222222', 'Apartment 9, G-10, Islamabad', '35202-2222222-2', 'Buyer'),
('Mishal', 'Noreen', 'mishal.noreen@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-322-3333333', 'House 33, H-9, Islamabad', '35202-3333333-3', 'Landlord'),
('Talha', 'Rashid', 'talha.rashid@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-322-4444444', 'Villa 11, DHA Phase 5', '35202-4444444-4', 'Seller'),
('Hira', 'Asad', 'hira.asad@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-322-5555555', 'House 67, I-10, Islamabad', '35202-5555555-5', 'Buyer'),
('Farhan', 'Saeed', 'farhan.saeed@gmail.com', '$2a$10$qM1M03vFTC9tsPa8JJfm3ebWv91W7WMC7qIRJRzf9rXMEZbIPGcKC', '+92-322-6666666', 'Apartment 5, F-11, Islamabad', '35202-6666666-6', 'Renter');

-- =============================================
-- Insert Properties (20 properties with PKR prices)
-- =============================================
INSERT INTO Property (agent_id, type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for) VALUES
(1, 1, 1, 'Modern 5-Bedroom House F-7 Markaz', 'Beautifully designed modern house with garden, garage, and servant quarters near F-7 Markaz.', 95000000.00, 4500, 5, 6, 2020, 'Available', 'Sale'),
(1, 2, 6, 'Luxury Villa Bahria Enclave', 'Premium villa with swimming pool, landscaped garden, and smart home features in Bahria Enclave.', 180000000.00, 8000, 6, 7, 2022, 'Available', 'Sale'),
(2, 1, 7, 'Elegant House DHA Phase II', 'Corner property with excellent location in DHA Phase II with modern amenities.', 120000000.00, 5500, 5, 5, 2019, 'Available', 'Sale'),
(2, 3, 9, 'Premium Apartment E-11/4', 'Spacious 3-bedroom apartment in E-11/4 with parking and security.', 45000000.00, 2200, 3, 3, 2021, 'Available', 'Sale'),
(3, 4, 8, 'Prime Plot G-13', 'Excellent investment opportunity in developing G-13 sector.', 25000000.00, 2178, 0, 0, NULL, 'Available', 'Sale'),
(3, 1, 17, 'Family Home H-9 Sector', 'Spacious family home in quiet H-9 Sector with basement and lawn.', 75000000.00, 5000, 4, 5, 2023, 'Available', 'Sale'),
(4, 5, 3, 'Commercial Office Blue Area', 'Prime commercial office space in Blue Area with parking.', 110000000.00, 3200, 0, 2, 2018, 'Available', 'Sale'),
(4, 2, 22, 'Executive Villa Bani Gala', 'Ultra-luxury villa in Bani Gala with panoramic lake views.', 350000000.00, 10000, 7, 8, 2023, 'Available', 'Sale'),
(5, 1, 4, 'Cozy House I-8/3', 'Well-maintained house in I-8/3 with modern kitchen and garage.', 65000000.00, 3500, 4, 4, 2015, 'Available', 'Sale'),
(5, 7, 21, 'Farmhouse Chak Shahzad', 'Beautiful farmhouse in Chak Shahzad with large grounds and orchard.', 150000000.00, 20000, 5, 5, 2020, 'Rented', 'Rent'),
(6, 1, 18, 'Modern House F-11/2', 'Newly constructed house in F-11/2 with contemporary design.', 55000000.00, 3200, 4, 4, 2024, 'Available', 'Sale'),
(6, 4, 26, 'Plot near Margalla Hills', 'Premium plot with stunning Margalla Hills view.', 35000000.00, 4356, 0, 0, NULL, 'Available', 'Sale'),
(7, 2, 23, 'Luxury Villa Bahria Town Phase 4', 'Exclusive villa in Bahria Town Phase 4 with all amenities.', 125000000.00, 6000, 5, 6, 2021, 'Available', 'Sale'),
(7, 3, 24, 'Student Apartment near NUST H-12', 'Ideal apartment near NUST university for students or faculty.', 28000000.00, 1500, 2, 2, 2022, 'Available', 'Rent'),
(8, 1, 25, 'Family House G-9/4', 'Well-located family home in G-9/4 with excellent ventilation.', 72000000.00, 3800, 4, 5, 2016, 'Available', 'Sale'),
(8, 6, 19, 'Penthouse G-10/1', 'Stunning penthouse in G-10/1 with rooftop terrace and city views.', 85000000.00, 4200, 4, 4, 2022, 'Available', 'Sale'),
(9, 1, 27, 'House I-10/2', 'Spacious house in I-10/2 with garden and parking.', 58000000.00, 3600, 4, 4, 2019, 'Available', 'Sale'),
(9, 5, 28, 'Commercial Space Parliament House Area', 'Premium commercial space near Parliament House.', 200000000.00, 5000, 0, 4, 2020, 'Available', 'Sale'),
(10, 1, 29, 'Modern House G-8/1', 'Contemporary design house in G-8/1 with smart home features.', 68000000.00, 3400, 4, 4, 2021, 'Available', 'Sale'),
(10, 9, 20, 'Duplex PWD Housing Society', 'Beautiful duplex in PWD Housing Society with double height living area.', 48000000.00, 2800, 3, 3, 2023, 'Available', 'Sale');

-- =============================================
-- Insert Listings (15 active listings)
-- =============================================
INSERT INTO Listing (property_id, agent_id, listing_date, expiry_date, listing_price, listing_status, description, featured, views_count) VALUES
(1, 1, '2024-01-15', '2024-07-15', 95000000.00, 'Active', 'Premium listing - Modern house in prime F-7 Markaz location', TRUE, 245),
(2, 1, '2024-02-01', '2024-08-01', 180000000.00, 'Active', 'Exclusive Bahria Enclave luxury villa with pool', TRUE, 312),
(3, 2, '2024-01-20', '2024-07-20', 120000000.00, 'Active', 'Beautiful DHA Phase II house with modern design', TRUE, 189),
(4, 2, '2024-02-10', '2024-08-10', 45000000.00, 'Active', 'Spacious E-11/4 apartment with great amenities', FALSE, 156),
(5, 3, '2024-01-25', '2024-07-25', 25000000.00, 'Active', 'Investment opportunity in G-13', FALSE, 98),
(6, 3, '2024-02-15', '2024-08-15', 75000000.00, 'Active', 'Perfect family home in H-9 Sector', TRUE, 203),
(7, 4, '2024-01-30', '2024-07-30', 110000000.00, 'Active', 'Prime Blue Area commercial office', FALSE, 167),
(8, 4, '2024-02-20', '2024-08-20', 350000000.00, 'Active', 'Ultra-luxury Bani Gala villa with lake views', TRUE, 425),
(9, 5, '2024-02-05', '2024-08-05', 65000000.00, 'Active', 'Affordable I-8/3 family house', FALSE, 134),
(10, 5, '2024-02-25', '2024-08-25', 150000000.00, 'Sold', 'Farmhouse Chak Shahzad - RENTED', FALSE, 278),
(11, 6, '2024-03-01', '2024-09-01', 55000000.00, 'Active', 'New construction in F-11/2', FALSE, 89),
(12, 6, '2024-03-05', '2024-09-05', 35000000.00, 'Active', 'Margalla Hills view plot', FALSE, 67),
(13, 7, '2024-03-10', '2024-09-10', 125000000.00, 'Active', 'Bahria Town Phase 4 villa', TRUE, 156),
(14, 7, '2024-03-15', '2024-09-15', 28000000.00, 'Active', 'NUST area student apartment', FALSE, 123),
(15, 8, '2024-03-20', '2024-09-20', 72000000.00, 'Active', 'G-9/4 family residence', FALSE, 145);

-- =============================================
-- Insert Transactions (10 transactions in PKR)
-- =============================================
INSERT INTO Transaction (listing_id, client_id, transaction_type, transaction_date, amount, commission, status, notes) VALUES
(10, 4, 'Rent', '2024-03-01', 450000.00, 45000.00, 'Completed', 'Monthly rental agreement for Chak Shahzad farmhouse'),
(2, 1, 'Sale', '2024-03-15', 180000000.00, 4500000.00, 'Pending', 'Negotiation in progress for Bahria Enclave villa'),
(3, 2, 'Sale', '2024-02-28', 118000000.00, 2950000.00, 'Completed', 'Successfully sold DHA Phase II house'),
(5, 5, 'Sale', '2024-03-10', 24000000.00, 600000.00, 'Completed', 'Plot sold in G-13'),
(8, 3, 'Sale', '2024-03-20', 350000000.00, 8750000.00, 'Pending', 'High-value Bani Gala villa under negotiation'),
(1, 6, 'Sale', '2024-03-25', 93000000.00, 2325000.00, 'Completed', 'F-7 Markaz house sold'),
(6, 7, 'Sale', '2024-04-01', 74000000.00, 1850000.00, 'Pending', 'H-9 Sector house purchase in progress'),
(4, 9, 'Sale', '2024-04-05', 44000000.00, 1100000.00, 'Completed', 'E-11/4 apartment sold'),
(11, 10, 'Rent', '2024-04-10', 280000.00, 28000.00, 'Completed', 'F-11/2 house rented'),
(13, 11, 'Sale', '2024-04-15', 122000000.00, 3050000.00, 'Pending', 'Bahria Town Phase 4 villa negotiation');

-- =============================================
-- Insert Payments (12 payments in PKR)
-- =============================================
INSERT INTO Payment (transaction_id, payment_date, amount, payment_method, payment_status, reference_number, notes) VALUES
(1, '2024-03-01', 450000.00, 'Bank Transfer', 'Completed', 'PAY-2024-001', 'First month rent payment - Chak Shahzad'),
(3, '2024-02-28', 50000000.00, 'Bank Transfer', 'Completed', 'PAY-2024-002', 'Initial payment 40% - DHA Phase II'),
(3, '2024-03-15', 68000000.00, 'Bank Transfer', 'Completed', 'PAY-2024-003', 'Final payment - DHA Phase II'),
(4, '2024-03-10', 24000000.00, 'Bank Transfer', 'Completed', 'PAY-2024-004', 'Full payment for G-13 plot'),
(6, '2024-03-25', 30000000.00, 'Bank Transfer', 'Completed', 'PAY-2024-005', 'Advance payment 32% - F-7 Markaz'),
(6, '2024-04-10', 63000000.00, 'Bank Transfer', 'Pending', 'PAY-2024-006', 'Balance payment pending - F-7 Markaz'),
(2, '2024-03-20', 50000000.00, 'Bank Transfer', 'Completed', 'PAY-2024-007', 'Token payment for Bahria Enclave villa'),
(5, '2024-03-22', 100000000.00, 'Bank Transfer', 'Pending', 'PAY-2024-008', 'Initial payment for Bani Gala villa'),
(8, '2024-04-05', 44000000.00, 'Bank Transfer', 'Completed', 'PAY-2024-009', 'Full payment - E-11/4 apartment'),
(9, '2024-04-10', 280000.00, 'Cash', 'Completed', 'PAY-2024-010', 'First month rent - F-11/2'),
(7, '2024-04-02', 25000000.00, 'Cheque', 'Completed', 'PAY-2024-011', 'Advance payment - H-9 Sector'),
(10, '2024-04-16', 40000000.00, 'Bank Transfer', 'Pending', 'PAY-2024-012', 'Token - Bahria Town Phase 4');

-- =============================================
-- Insert Contracts (10 contracts)
-- =============================================
INSERT INTO Contract (transaction_id, contract_date, start_date, end_date, terms, contract_type, status, document_path) VALUES
(1, '2024-03-01', '2024-03-01', '2025-03-01', 'Standard 12-month rental agreement with renewal option', 'Rental', 'Active', '/contracts/rental_001.pdf'),
(3, '2024-02-28', '2024-02-28', NULL, 'Standard sale agreement with possession transfer', 'Sale', 'Completed', '/contracts/sale_003.pdf'),
(4, '2024-03-10', '2024-03-10', NULL, 'Plot sale agreement with registry transfer', 'Sale', 'Completed', '/contracts/sale_004.pdf'),
(6, '2024-03-25', '2024-03-25', NULL, 'Sale agreement with installment plan', 'Sale', 'Active', '/contracts/sale_006.pdf'),
(2, '2024-03-18', '2024-03-18', NULL, 'Preliminary sale agreement pending final payment', 'Sale', 'Draft', '/contracts/sale_002.pdf'),
(5, '2024-03-22', '2024-03-22', NULL, 'Luxury property sale agreement with special terms', 'Sale', 'Draft', '/contracts/sale_005.pdf'),
(8, '2024-04-05', '2024-04-05', NULL, 'Apartment sale with immediate possession', 'Sale', 'Completed', '/contracts/sale_008.pdf'),
(9, '2024-04-10', '2024-04-10', '2025-04-10', 'One year rental agreement - F-11/2', 'Rental', 'Active', '/contracts/rental_009.pdf'),
(7, '2024-04-02', '2024-04-02', NULL, 'Sale agreement - H-9 Sector house', 'Sale', 'Active', '/contracts/sale_007.pdf'),
(10, '2024-04-16', '2024-04-16', NULL, 'Preliminary agreement - Bahria Town', 'Sale', 'Draft', '/contracts/sale_010.pdf');

-- =============================================
-- Insert Inspections (12 inspections)
-- =============================================
INSERT INTO Inspection (listing_id, client_id, inspection_date, inspection_time, status, notes, agent_feedback) VALUES
(1, 1, '2024-03-10', '10:00:00', 'Completed', 'Daniyal interested in F-7 Markaz property', 'Very interested, discussing price'),
(2, 1, '2024-03-12', '14:00:00', 'Completed', 'Showing Bahria Enclave luxury villa', 'Client impressed with amenities'),
(3, 2, '2024-02-25', '11:00:00', 'Completed', 'DHA Phase II house inspection', 'Noor confirmed purchase'),
(4, 3, '2024-03-05', '15:00:00', 'Completed', 'E-11/4 apartment tour', 'Saad considering options'),
(6, 4, '2024-03-08', '10:30:00', 'Completed', 'H-9 Sector showing', 'Laiba liked the location'),
(8, 3, '2024-03-18', '16:00:00', 'Completed', 'Bani Gala villa exclusive showing', 'High interest, negotiation started'),
(13, 5, '2024-03-22', '11:00:00', 'Scheduled', 'Bahria Town Phase 4 villa inspection', NULL),
(7, 6, '2024-03-25', '14:30:00', 'Scheduled', 'Blue Area commercial office showing', NULL),
(9, 7, '2024-03-28', '10:00:00', 'Scheduled', 'I-8/3 house tour', NULL),
(14, 10, '2024-03-30', '15:00:00', 'Cancelled', 'Emaan rescheduled', 'Client busy, will reschedule'),
(15, 11, '2024-04-01', '11:00:00', 'Completed', 'G-9/4 house viewing', 'Fahad very interested'),
(12, 14, '2024-04-03', '14:00:00', 'Scheduled', 'Margalla Hills plot inspection', NULL);

-- =============================================
-- Insert Feedback (10 feedback entries)
-- =============================================
INSERT INTO Feedback (listing_id, client_id, rating, comment, feedback_date) VALUES
(1, 1, 5, 'Excellent property! Well-maintained and great location in F-7 Markaz.', '2024-03-11'),
(2, 1, 5, 'Luxurious villa with stunning features in Bahria Enclave. Highly recommended.', '2024-03-13'),
(3, 2, 5, 'Beautiful house in DHA Phase II. Very peaceful area.', '2024-02-26'),
(4, 3, 4, 'Good apartment but slightly overpriced for E-11/4 area.', '2024-03-06'),
(6, 4, 4, 'Nice house in H-9 with beautiful views. Needs minor repairs.', '2024-03-09'),
(8, 3, 5, 'Exceptional luxury property in Bani Gala. Worth every rupee.', '2024-03-19'),
(5, 5, 4, 'Good investment plot in G-13. Access roads need improvement.', '2024-03-12'),
(7, 6, 5, 'Perfect commercial space in Blue Area.', '2024-03-26'),
(10, 4, 5, 'Wonderful farmhouse in Chak Shahzad. Great for family retreats.', '2024-03-02'),
(15, 11, 4, 'G-9/4 house has good potential but needs some renovation.', '2024-04-02');

-- =============================================
-- Summary Query
-- =============================================
SELECT 'Data Import Summary' as '';
SELECT 'Agencies' as TableName, COUNT(*) as RecordCount FROM Agency
UNION SELECT 'Property Types', COUNT(*) FROM Property_Type
UNION SELECT 'Locations', COUNT(*) FROM Location
UNION SELECT 'Agents', COUNT(*) FROM Agent
UNION SELECT 'Clients', COUNT(*) FROM Client
UNION SELECT 'Properties', COUNT(*) FROM Property
UNION SELECT 'Listings', COUNT(*) FROM Listing
UNION SELECT 'Transactions', COUNT(*) FROM Transaction
UNION SELECT 'Payments', COUNT(*) FROM Payment
UNION SELECT 'Contracts', COUNT(*) FROM Contract
UNION SELECT 'Inspections', COUNT(*) FROM Inspection
UNION SELECT 'Feedback', COUNT(*) FROM Feedback;
