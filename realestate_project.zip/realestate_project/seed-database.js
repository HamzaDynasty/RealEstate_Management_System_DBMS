// Complete database reset and seed script
const bcrypt = require('bcryptjs');
const pool = require('./config/db');

async function seedDatabase() {
    console.log('🔄 Complete Database Reset and Seed...\n');

    try {
        // Disable foreign key checks for clean truncation
        await pool.query('SET FOREIGN_KEY_CHECKS = 0');

        // Truncate all tables
        const tables = ['Feedback', 'Inspection', 'Contract', 'Payment', 'Transaction', 'Listing', 'Property', 'Location', 'Property_Type', 'Client', 'Agent', 'Agency'];
        for (const table of tables) {
            await pool.query(`TRUNCATE TABLE ${table}`);
            console.log(`  Truncated ${table}`);
        }

        // Re-enable foreign key checks
        await pool.query('SET FOREIGN_KEY_CHECKS = 1');
        console.log('\n✅ Tables cleared\n');

        const password = await bcrypt.hash('password123', 10);

        // 1. Insert Agencies
        await pool.query(`INSERT INTO Agency (agency_name, email, password, phone, address, license_number) VALUES
            ('Prime Properties Islamabad', 'admin@primeproperties.pk', ?, '+92-51-1234567', 'F-7 Markaz, Islamabad', 'REA-2024-001'),
            ('Elite Realty Pakistan', 'admin@eliterealty.pk', ?, '+92-51-2345678', 'Blue Area, Islamabad', 'REA-2024-002'),
            ('Capital Estate Advisors', 'admin@capitalestate.pk', ?, '+92-51-3456789', 'F-10 Markaz, Islamabad', 'REA-2024-003')`,
            [password, password, password]);
        console.log('✅ Agencies inserted');

        // 2. Insert Property Types
        await pool.query(`INSERT INTO Property_Type (type_name, description) VALUES
            ('House', 'Independent residential house'), ('Villa', 'Luxury standalone property'),
            ('Apartment', 'Multi-story unit'), ('Plot', 'Empty land'), ('Commercial', 'Office/retail'),
            ('Penthouse', 'Luxury top-floor'), ('Farmhouse', 'Rural property'), ('Studio', 'Single room'),
            ('Duplex', 'Two-floor unit'), ('Townhouse', 'Row house')`);
        console.log('✅ Property Types inserted');

        // 3. Insert Locations
        await pool.query(`INSERT INTO Location (address, city, area, postal_code) VALUES
            ('House 14, F-7 Markaz', 'Islamabad', 'F-7 Markaz', '44000'),
            ('Plot 28, G-6 Sector', 'Islamabad', 'G-6 Sector', '44000'),
            ('Office 305, Blue Area', 'Islamabad', 'Blue Area', '44000'),
            ('House 45, I-8/3', 'Islamabad', 'I-8/3', '44000'),
            ('Shop 15, F-10 Markaz', 'Islamabad', 'F-10 Markaz', '44000'),
            ('Villa 22, Bahria Enclave', 'Islamabad', 'Bahria Enclave', '44000'),
            ('House 88, DHA Phase II', 'Islamabad', 'DHA Phase II', '44000'),
            ('Plot 55, G-13', 'Islamabad', 'G-13', '44000'),
            ('Apartment 12, E-11/4', 'Islamabad', 'E-11/4', '44000'),
            ('Shop 8, F-6 Super Market', 'Islamabad', 'F-6 Super Market', '44000'),
            ('Office 201, Giga Mall', 'Islamabad', 'Giga Mall DHA', '44000'),
            ('Shop 45, Centaurus Mall', 'Islamabad', 'Centaurus Mall', '44000'),
            ('Plot, Shakarparian', 'Islamabad', 'Pakistan Monument', '44000'),
            ('Warehouse, I-9 Industrial', 'Islamabad', 'I-9 Industrial', '44000'),
            ('Villa 3, G-5 Diplomatic', 'Islamabad', 'G-5 Diplomatic', '44000'),
            ('Villa, Rawal Lake', 'Islamabad', 'Rawal Lake View', '44000'),
            ('House 77, H-9 Sector', 'Islamabad', 'H-9 Sector', '44000'),
            ('House 33, F-11/2', 'Islamabad', 'F-11/2', '44000'),
            ('Apartment, G-10/1', 'Islamabad', 'G-10/1', '44000'),
            ('House, PWD Housing', 'Islamabad', 'PWD Housing', '44000'),
            ('Farmhouse, Chak Shahzad', 'Islamabad', 'Chak Shahzad', '44000'),
            ('Villa 18, Bani Gala', 'Islamabad', 'Bani Gala', '44000'),
            ('House, Bahria Phase 4', 'Rawalpindi', 'Bahria Phase 4', '46000'),
            ('Apartment, NUST H-12', 'Islamabad', 'NUST H-12', '44000'),
            ('House 29, G-9/4', 'Islamabad', 'G-9/4', '44000'),
            ('Plot, Margalla Hills', 'Islamabad', 'Margalla Hills', '44000'),
            ('House 44, I-10/2', 'Islamabad', 'I-10/2', '44000'),
            ('Office, Parliament House', 'Islamabad', 'Parliament House', '44000'),
            ('House 56, G-8/1', 'Islamabad', 'G-8/1', '44000'),
            ('Office, F-5 Red Zone', 'Islamabad', 'F-5 Red Zone', '44000')`);
        console.log('✅ Locations inserted');

        // 4. Insert Agents
        await pool.query(`INSERT INTO Agent (agency_id, first_name, last_name, email, password, phone, license_number, commission_rate, hire_date) VALUES
            (1, 'Ahmed', 'Raza', 'ahmed.raza@primeproperties.pk', ?, '+92-300-1111111', 'AGT-001', 2.50, '2023-01-15'),
            (1, 'Hania', 'Malik', 'hania.malik@primeproperties.pk', ?, '+92-300-2222222', 'AGT-002', 2.75, '2023-03-20'),
            (1, 'Bilal', 'Ahmed', 'bilal.ahmed@primeproperties.pk', ?, '+92-300-3333333', 'AGT-003', 2.50, '2023-06-10'),
            (2, 'Ayesha', 'Siddiqui', 'ayesha.siddiqui@eliterealty.pk', ?, '+92-300-4444444', 'AGT-004', 3.00, '2023-02-01'),
            (2, 'Umar', 'Farooq', 'umar.farooq@eliterealty.pk', ?, '+92-300-5555555', 'AGT-005', 2.50, '2023-05-15'),
            (2, 'Rimsha', 'Khan', 'rimsha.khan@eliterealty.pk', ?, '+92-300-6666666', 'AGT-006', 2.75, '2023-07-01'),
            (3, 'Hamza', 'Ali', 'hamza.ali@capitalestate.pk', ?, '+92-300-7777777', 'AGT-007', 2.50, '2023-04-10'),
            (3, 'Maryam', 'Javed', 'maryam.javed@capitalestate.pk', ?, '+92-300-8888888', 'AGT-008', 3.00, '2023-08-15'),
            (3, 'Shahzaib', 'Aslam', 'shahzaib.aslam@capitalestate.pk', ?, '+92-300-9999999', 'AGT-009', 2.50, '2023-09-01'),
            (1, 'Hafsa', 'Tariq', 'hafsa.tariq@primeproperties.pk', ?, '+92-301-1111111', 'AGT-010', 2.75, '2023-10-01')`,
            [password, password, password, password, password, password, password, password, password, password]);
        console.log('✅ Agents inserted');

        // 5. Insert Clients
        await pool.query(`INSERT INTO Client (first_name, last_name, email, password, phone, address, cnic, client_type) VALUES
            ('Daniyal', 'Sheikh', 'daniyal.sheikh@gmail.com', ?, '+92-321-1111111', 'G-9, Islamabad', '35201-1111111-1', 'Buyer'),
            ('Noor', 'Fatima', 'noor.fatima@gmail.com', ?, '+92-321-2222222', 'F-10, Islamabad', '35201-2222222-2', 'Buyer'),
            ('Saad', 'Mehmood', 'saad.mehmood@gmail.com', ?, '+92-321-3333333', 'DHA Phase 2', '35201-3333333-3', 'Seller'),
            ('Laiba', 'Anwar', 'laiba.anwar@gmail.com', ?, '+92-321-4444444', 'I-8, Islamabad', '35201-4444444-4', 'Renter'),
            ('Zain-ul', 'Abidin', 'zain.abidin@gmail.com', ?, '+92-321-5555555', 'Blue Area', '35201-5555555-5', 'Buyer'),
            ('Mehwish', 'Akram', 'mehwish.akram@gmail.com', ?, '+92-321-6666666', 'G-11, Islamabad', '35201-6666666-6', 'Landlord'),
            ('Ali', 'Shan', 'ali.shan@gmail.com', ?, '+92-321-7777777', 'F-7, Islamabad', '35201-7777777-7', 'Buyer'),
            ('Saba', 'Qureshi', 'saba.qureshi@gmail.com', ?, '+92-321-8888888', 'E-11, Islamabad', '35201-8888888-8', 'Seller'),
            ('Salman', 'Yousaf', 'salman.yousaf@gmail.com', ?, '+92-321-9999999', 'Bahria Enclave', '35201-9999999-9', 'Buyer'),
            ('Emaan', 'Feroze', 'emaan.feroze@gmail.com', ?, '+92-322-1111111', 'F-8, Islamabad', '35202-1111111-1', 'Renter'),
            ('Fahad', 'Iqbal', 'fahad.iqbal@gmail.com', ?, '+92-322-2222222', 'G-10, Islamabad', '35202-2222222-2', 'Buyer'),
            ('Mishal', 'Noreen', 'mishal.noreen@gmail.com', ?, '+92-322-3333333', 'H-9, Islamabad', '35202-3333333-3', 'Landlord'),
            ('Talha', 'Rashid', 'talha.rashid@gmail.com', ?, '+92-322-4444444', 'DHA Phase 5', '35202-4444444-4', 'Seller'),
            ('Hira', 'Asad', 'hira.asad@gmail.com', ?, '+92-322-5555555', 'I-10, Islamabad', '35202-5555555-5', 'Buyer'),
            ('Farhan', 'Saeed', 'farhan.saeed@gmail.com', ?, '+92-322-6666666', 'F-11, Islamabad', '35202-6666666-6', 'Renter')`,
            [password, password, password, password, password, password, password, password, password, password, password, password, password, password, password]);
        console.log('✅ Clients inserted');

        // 6. Insert Properties (PKR prices)
        await pool.query(`INSERT INTO Property (agent_id, type_id, location_id, title, description, price, area_sqft, bedrooms, bathrooms, year_built, status, property_for) VALUES
            (1, 1, 1, 'Modern House F-7 Markaz', 'Beautiful house with garden', 95000000, 4500, 5, 6, 2020, 'Available', 'Sale'),
            (1, 2, 6, 'Luxury Villa Bahria Enclave', 'Premium villa with pool', 180000000, 8000, 6, 7, 2022, 'Available', 'Sale'),
            (2, 1, 7, 'Elegant House DHA Phase II', 'Corner property', 120000000, 5500, 5, 5, 2019, 'Available', 'Sale'),
            (2, 3, 9, 'Premium Apartment E-11/4', 'Spacious 3-bed apartment', 45000000, 2200, 3, 3, 2021, 'Available', 'Sale'),
            (3, 4, 8, 'Prime Plot G-13', 'Investment opportunity', 25000000, 2178, 0, 0, NULL, 'Available', 'Sale'),
            (3, 1, 17, 'Family Home H-9', 'Spacious family home', 75000000, 5000, 4, 5, 2023, 'Available', 'Sale'),
            (4, 5, 3, 'Commercial Office Blue Area', 'Prime office space', 110000000, 3200, 0, 2, 2018, 'Available', 'Sale'),
            (4, 2, 22, 'Executive Villa Bani Gala', 'Ultra-luxury villa', 350000000, 10000, 7, 8, 2023, 'Available', 'Sale'),
            (5, 1, 4, 'Cozy House I-8/3', 'Well-maintained house', 65000000, 3500, 4, 4, 2015, 'Available', 'Sale'),
            (5, 7, 21, 'Farmhouse Chak Shahzad', 'Beautiful farmhouse', 150000000, 20000, 5, 5, 2020, 'Rented', 'Rent'),
            (6, 1, 18, 'Modern House F-11/2', 'Contemporary design', 55000000, 3200, 4, 4, 2024, 'Available', 'Sale'),
            (6, 4, 26, 'Plot Margalla Hills', 'Stunning view', 35000000, 4356, 0, 0, NULL, 'Available', 'Sale'),
            (7, 2, 23, 'Villa Bahria Phase 4', 'Exclusive villa', 125000000, 6000, 5, 6, 2021, 'Available', 'Sale'),
            (7, 3, 24, 'Apartment near NUST', 'Ideal for students', 28000000, 1500, 2, 2, 2022, 'Available', 'Rent'),
            (8, 1, 25, 'Family House G-9/4', 'Well-located home', 72000000, 3800, 4, 5, 2016, 'Available', 'Sale'),
            (8, 6, 19, 'Penthouse G-10/1', 'Stunning penthouse', 85000000, 4200, 4, 4, 2022, 'Available', 'Sale'),
            (9, 1, 27, 'House I-10/2', 'Spacious house', 58000000, 3600, 4, 4, 2019, 'Available', 'Sale'),
            (9, 5, 28, 'Commercial Parliament', 'Premium location', 200000000, 5000, 0, 4, 2020, 'Available', 'Sale'),
            (10, 1, 29, 'Modern House G-8/1', 'Smart home features', 68000000, 3400, 4, 4, 2021, 'Available', 'Sale'),
            (10, 9, 20, 'Duplex PWD Housing', 'Beautiful duplex', 48000000, 2800, 3, 3, 2023, 'Available', 'Sale')`);
        console.log('✅ Properties inserted');

        // 7. Insert Listings
        await pool.query(`INSERT INTO Listing (property_id, agent_id, listing_date, expiry_date, listing_price, listing_status, description, featured, views_count) VALUES
            (1, 1, '2024-01-15', '2024-07-15', 95000000, 'Active', 'Premium F-7 listing', TRUE, 245),
            (2, 1, '2024-02-01', '2024-08-01', 180000000, 'Active', 'Exclusive Bahria villa', TRUE, 312),
            (3, 2, '2024-01-20', '2024-07-20', 120000000, 'Active', 'DHA Phase II house', TRUE, 189),
            (4, 2, '2024-02-10', '2024-08-10', 45000000, 'Active', 'E-11/4 apartment', FALSE, 156),
            (5, 3, '2024-01-25', '2024-07-25', 25000000, 'Active', 'G-13 investment', FALSE, 98),
            (6, 3, '2024-02-15', '2024-08-15', 75000000, 'Active', 'H-9 family home', TRUE, 203),
            (7, 4, '2024-01-30', '2024-07-30', 110000000, 'Active', 'Blue Area office', FALSE, 167),
            (8, 4, '2024-02-20', '2024-08-20', 350000000, 'Active', 'Bani Gala luxury', TRUE, 425),
            (9, 5, '2024-02-05', '2024-08-05', 65000000, 'Active', 'I-8/3 house', FALSE, 134),
            (10, 5, '2024-02-25', '2024-08-25', 150000000, 'Sold', 'Chak Shahzad farmhouse', FALSE, 278),
            (11, 6, '2024-03-01', '2024-09-01', 55000000, 'Active', 'F-11/2 new', FALSE, 89),
            (12, 6, '2024-03-05', '2024-09-05', 35000000, 'Active', 'Margalla view', FALSE, 67),
            (13, 7, '2024-03-10', '2024-09-10', 125000000, 'Active', 'Bahria Phase 4', TRUE, 156),
            (14, 7, '2024-03-15', '2024-09-15', 28000000, 'Active', 'NUST apartment', FALSE, 123),
            (15, 8, '2024-03-20', '2024-09-20', 72000000, 'Active', 'G-9/4 residence', FALSE, 145)`);
        console.log('✅ Listings inserted');

        // 8. Insert Transactions (PKR)
        await pool.query(`INSERT INTO Transaction (listing_id, client_id, transaction_type, transaction_date, amount, commission, status, notes) VALUES
            (10, 4, 'Rent', '2024-03-01', 450000, 45000, 'Completed', 'Monthly rent - Chak Shahzad'),
            (2, 1, 'Sale', '2024-03-15', 180000000, 4500000, 'Pending', 'Bahria Enclave villa'),
            (3, 2, 'Sale', '2024-02-28', 118000000, 2950000, 'Completed', 'DHA Phase II house'),
            (5, 5, 'Sale', '2024-03-10', 24000000, 600000, 'Completed', 'G-13 plot sold'),
            (8, 3, 'Sale', '2024-03-20', 350000000, 8750000, 'Pending', 'Bani Gala villa'),
            (1, 6, 'Sale', '2024-03-25', 93000000, 2325000, 'Completed', 'F-7 Markaz house'),
            (6, 7, 'Sale', '2024-04-01', 74000000, 1850000, 'Pending', 'H-9 house'),
            (4, 9, 'Sale', '2024-04-05', 44000000, 1100000, 'Completed', 'E-11/4 apartment'),
            (11, 10, 'Rent', '2024-04-10', 280000, 28000, 'Completed', 'F-11/2 rent'),
            (13, 11, 'Sale', '2024-04-15', 122000000, 3050000, 'Pending', 'Bahria Phase 4')`);
        console.log('✅ Transactions inserted');

        // 9. Insert Payments
        await pool.query(`INSERT INTO Payment (transaction_id, payment_date, amount, payment_method, payment_status, reference_number, notes) VALUES
            (1, '2024-03-01', 450000, 'Bank Transfer', 'Completed', 'PAY-001', 'First month rent'),
            (3, '2024-02-28', 50000000, 'Bank Transfer', 'Completed', 'PAY-002', 'Initial 40%'),
            (3, '2024-03-15', 68000000, 'Bank Transfer', 'Completed', 'PAY-003', 'Final payment'),
            (4, '2024-03-10', 24000000, 'Bank Transfer', 'Completed', 'PAY-004', 'Full payment'),
            (6, '2024-03-25', 30000000, 'Bank Transfer', 'Completed', 'PAY-005', 'Advance 32%'),
            (6, '2024-04-10', 63000000, 'Bank Transfer', 'Pending', 'PAY-006', 'Balance pending'),
            (2, '2024-03-20', 50000000, 'Bank Transfer', 'Completed', 'PAY-007', 'Token for Bahria'),
            (5, '2024-03-22', 100000000, 'Bank Transfer', 'Pending', 'PAY-008', 'Bani Gala initial'),
            (8, '2024-04-05', 44000000, 'Bank Transfer', 'Completed', 'PAY-009', 'E-11 full'),
            (9, '2024-04-10', 280000, 'Cash', 'Completed', 'PAY-010', 'F-11 rent'),
            (7, '2024-04-02', 25000000, 'Cheque', 'Completed', 'PAY-011', 'H-9 advance'),
            (10, '2024-04-16', 40000000, 'Bank Transfer', 'Pending', 'PAY-012', 'Bahria token')`);
        console.log('✅ Payments inserted');

        // 10. Insert Contracts
        await pool.query(`INSERT INTO Contract (transaction_id, contract_date, start_date, end_date, terms, contract_type, status, document_path) VALUES
            (1, '2024-03-01', '2024-03-01', '2025-03-01', '12-month rental agreement', 'Rental', 'Active', '/contracts/rental_001.pdf'),
            (3, '2024-02-28', '2024-02-28', NULL, 'Sale agreement with possession', 'Sale', 'Completed', '/contracts/sale_003.pdf'),
            (4, '2024-03-10', '2024-03-10', NULL, 'Plot sale with registry', 'Sale', 'Completed', '/contracts/sale_004.pdf'),
            (6, '2024-03-25', '2024-03-25', NULL, 'Installment plan agreement', 'Sale', 'Active', '/contracts/sale_006.pdf'),
            (2, '2024-03-18', '2024-03-18', NULL, 'Preliminary sale agreement', 'Sale', 'Draft', '/contracts/sale_002.pdf'),
            (5, '2024-03-22', '2024-03-22', NULL, 'Luxury property sale', 'Sale', 'Draft', '/contracts/sale_005.pdf'),
            (8, '2024-04-05', '2024-04-05', NULL, 'Apartment sale', 'Sale', 'Completed', '/contracts/sale_008.pdf'),
            (9, '2024-04-10', '2024-04-10', '2025-04-10', 'One year rental', 'Rental', 'Active', '/contracts/rental_009.pdf'),
            (7, '2024-04-02', '2024-04-02', NULL, 'H-9 sale agreement', 'Sale', 'Active', '/contracts/sale_007.pdf'),
            (10, '2024-04-16', '2024-04-16', NULL, 'Preliminary agreement', 'Sale', 'Draft', '/contracts/sale_010.pdf')`);
        console.log('✅ Contracts inserted');

        // 11. Insert Inspections
        await pool.query(`INSERT INTO Inspection (listing_id, client_id, inspection_date, inspection_time, status, notes, agent_feedback) VALUES
            (1, 1, '2024-03-10', '10:00:00', 'Completed', 'Daniyal interested', 'Very interested'),
            (2, 1, '2024-03-12', '14:00:00', 'Completed', 'Bahria villa tour', 'Impressed'),
            (3, 2, '2024-02-25', '11:00:00', 'Completed', 'DHA inspection', 'Confirmed purchase'),
            (4, 3, '2024-03-05', '15:00:00', 'Completed', 'E-11 apartment', 'Considering'),
            (6, 4, '2024-03-08', '10:30:00', 'Completed', 'H-9 showing', 'Liked location'),
            (8, 3, '2024-03-18', '16:00:00', 'Completed', 'Bani Gala tour', 'High interest'),
            (13, 5, '2024-03-22', '11:00:00', 'Scheduled', 'Bahria Phase 4', NULL),
            (7, 6, '2024-03-25', '14:30:00', 'Scheduled', 'Blue Area office', NULL),
            (9, 7, '2024-03-28', '10:00:00', 'Scheduled', 'I-8 house tour', NULL),
            (14, 10, '2024-03-30', '15:00:00', 'Cancelled', 'Client rescheduled', 'Will reschedule'),
            (15, 11, '2024-04-01', '11:00:00', 'Completed', 'G-9 viewing', 'Very interested'),
            (12, 14, '2024-04-03', '14:00:00', 'Scheduled', 'Margalla plot', NULL)`);
        console.log('✅ Inspections inserted');

        // 12. Insert Feedback
        await pool.query(`INSERT INTO Feedback (listing_id, client_id, rating, comment, feedback_date) VALUES
            (1, 1, 5, 'Excellent property! Great location in F-7.', '2024-03-11'),
            (2, 1, 5, 'Luxurious villa in Bahria. Highly recommended.', '2024-03-13'),
            (3, 2, 5, 'Beautiful DHA house. Very peaceful.', '2024-02-26'),
            (4, 3, 4, 'Good apartment but slightly overpriced.', '2024-03-06'),
            (6, 4, 4, 'Nice H-9 house. Needs minor repairs.', '2024-03-09'),
            (8, 3, 5, 'Exceptional Bani Gala villa. Worth it.', '2024-03-19'),
            (5, 5, 4, 'Good G-13 plot. Roads need work.', '2024-03-12'),
            (7, 6, 5, 'Perfect Blue Area location.', '2024-03-26'),
            (10, 4, 5, 'Wonderful farmhouse experience.', '2024-03-02'),
            (15, 11, 4, 'G-9 house has good potential.', '2024-04-02')`);
        console.log('✅ Feedback inserted');

        // Summary
        console.log('\n' + '═'.repeat(50));
        console.log('📊 DATABASE SUMMARY');
        console.log('═'.repeat(50));

        const tables2 = ['Agency', 'Property_Type', 'Location', 'Agent', 'Client', 'Property', 'Listing', 'Transaction', 'Payment', 'Contract', 'Inspection', 'Feedback'];
        for (const table of tables2) {
            const [rows] = await pool.query(`SELECT COUNT(*) as count FROM ${table}`);
            console.log(`   ${table.padEnd(15)} ${rows[0].count} records`);
        }

        console.log('═'.repeat(50));
        console.log('\n🔑 LOGIN CREDENTIALS (password: password123):\n');
        console.log('Admin:  admin@primeproperties.pk');
        console.log('Agent:  ahmed.raza@primeproperties.pk');
        console.log('Client: daniyal.sheikh@gmail.com\n');

        process.exit(0);
    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

seedDatabase();
