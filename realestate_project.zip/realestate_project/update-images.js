const pool = require('./config/db');

async function updateHouseVillaImages() {
    try {
        // Villa properties (type_id = 2)
        // Property 2: Luxury Villa Bahria Enclave
        await pool.query("UPDATE Property SET image_url = '/images/properties/villa1.jpg' WHERE property_id = 2");

        // Property 8: Executive Villa Bani Gala
        await pool.query("UPDATE Property SET image_url = '/images/properties/villa2.jpg' WHERE property_id = 8");

        // Property 13: Luxury Villa Bahria Town Phase 4
        await pool.query("UPDATE Property SET image_url = '/images/properties/villa1.jpg' WHERE property_id = 13");

        // House properties (type_id = 1)
        // Property 1: Modern 5-Bedroom House F-7 Markaz
        await pool.query("UPDATE Property SET image_url = '/images/properties/house1.jpg' WHERE property_id = 1");

        // Property 3: Elegant House DHA Phase II
        await pool.query("UPDATE Property SET image_url = '/images/properties/house2.jpg' WHERE property_id = 3");

        // Property 6: Family Home H-9 Sector
        await pool.query("UPDATE Property SET image_url = '/images/properties/house3.jpg' WHERE property_id = 6");

        // Property 9: Cozy House I-8/3
        await pool.query("UPDATE Property SET image_url = '/images/properties/house1.jpg' WHERE property_id = 9");

        // Property 11: Modern House F-11/2
        await pool.query("UPDATE Property SET image_url = '/images/properties/house2.jpg' WHERE property_id = 11");

        // Property 15: Family House G-9/4
        await pool.query("UPDATE Property SET image_url = '/images/properties/house3.jpg' WHERE property_id = 15");

        // Property 17: House I-10/2
        await pool.query("UPDATE Property SET image_url = '/images/properties/house1.jpg' WHERE property_id = 17");

        // Property 19: Modern House G-8/1
        await pool.query("UPDATE Property SET image_url = '/images/properties/house2.jpg' WHERE property_id = 19");

        console.log('✅ House and Villa images updated successfully!');

        // Verify
        const [results] = await pool.query(`
            SELECT p.property_id, p.title, pt.type_name, p.image_url 
            FROM Property p 
            JOIN Property_Type pt ON p.type_id = pt.type_id
            WHERE p.image_url IS NOT NULL 
            ORDER BY pt.type_name, p.property_id
        `);
        console.log('\nAll properties with images:');
        results.forEach(r => console.log(`  [${r.type_name}] ID ${r.property_id}: ${r.title}`));

        process.exit(0);
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

updateHouseVillaImages();
