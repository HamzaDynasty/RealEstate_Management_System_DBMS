// Fix passwords in database
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

async function fixPasswords() {
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'crystal12',
        database: 'real_estate_db'
    });

    console.log('Connected to database...');

    // Generate correct hash for password123
    const correctHash = await bcrypt.hash('password123', 10);
    console.log('Generated hash:', correctHash);

    // Update all passwords
    await connection.execute('UPDATE Agency SET password = ?', [correctHash]);
    console.log('Updated Agency passwords');

    await connection.execute('UPDATE Agent SET password = ?', [correctHash]);
    console.log('Updated Agent passwords');

    await connection.execute('UPDATE Client SET password = ?', [correctHash]);
    console.log('Updated Client passwords');

    // Verify
    const [agencies] = await connection.execute('SELECT email, password FROM Agency LIMIT 1');
    console.log('\nVerification - Agency:', agencies[0].email);

    const testMatch = await bcrypt.compare('password123', agencies[0].password);
    console.log('Password "password123" matches:', testMatch);

    await connection.end();
    console.log('\n=== DONE! Try logging in now ===');
}

fixPasswords().catch(console.error);
