const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from public directory
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/agent', require('./routes/agent'));
app.use('/api/client', require('./routes/client'));

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve HTML pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/login-admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login-admin.html'));
});

app.get('/login-agent', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login-agent.html'));
});

app.get('/login-client', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login-client.html'));
});

app.get('/signup-admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signup-admin.html'));
});

app.get('/signup-agent', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signup-agent.html'));
});

app.get('/signup-client', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signup-client.html'));
});

app.get('/admin-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-dashboard.html'));
});

app.get('/agent-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'agent-dashboard.html'));
});

app.get('/client-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'client-dashboard.html'));
});

app.get('/database-view', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'database-view.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ error: 'Not found' });
});

// Start server
app.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║   🏠 Real Estate Management System                         ║
║   ══════════════════════════════════                       ║
║                                                            ║
║   Server running on: http://localhost:${PORT}                 ║
║                                                            ║
║   Sample Login Credentials:                                ║
║   ─────────────────────────────────────                    ║
║   Admin:  admin@primeproperties.pk / password123           ║
║   Agent:  muhammad.ali@primeproperties.pk / password123    ║
║   Client: maryam.butt@gmail.com / password123              ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
    `);
});

module.exports = app;
