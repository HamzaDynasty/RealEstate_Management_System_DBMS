// Script to reset passwords in the database
const bcrypt = require('bcryptjs');
const pool = require('./config/db');

async function resetPasswords() {
    const password = 'password123';
    const hashedPassword = await bcrypt.hash(password, 10);

    console.log('Generated password hash:', hashedPassword);
    console.log('Updating all users with password: password123');

    try {
        // Update Agency (Admin) passwords
        await pool.query('UPDATE Agency SET password = ?', [hashedPassword]);
        console.log('✅ Agency passwords updated');

        // Update Agent passwords
        await pool.query('UPDATE Agent SET password = ?', [hashedPassword]);
        console.log('✅ Agent passwords updated');

        // Update Client passwords
        await pool.query('UPDATE Client SET password = ?', [hashedPassword]);
        console.log('✅ Client passwords updated');

        // Verify
        const [agencies] = await pool.query('SELECT agency_id, agency_name, email FROM Agency');
        console.log('\nAgencies:', agencies);

        const [agents] = await pool.query('SELECT agent_id, first_name, last_name, email FROM Agent');
        console.log('Agents:', agents);

        const [clients] = await pool.query('SELECT client_id, first_name, last_name, email FROM Client');
        console.log('Clients:', clients);

        console.log('\n✅ All passwords reset to: password123');
        console.log('\nYou can now login with:');
        console.log('  Admin:  admin@primeproperties.pk / password123');
        console.log('  Agent:  muhammad.ali@primeproperties.pk / password123');
        console.log('  Client: maryam.butt@gmail.com / password123');

        process.exit(0);
    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

resetPasswords();
