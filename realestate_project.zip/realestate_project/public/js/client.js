// Client Dashboard JavaScript
(function () {
    if (!requireAuth(['client'])) return;

    const user = Auth.getUser();
    document.getElementById('userName').textContent = user?.name || 'Client';

    let currentTab = 'dashboard';

    // Tab navigation
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tab = e.target.getAttribute('data-tab');
            switchTab(tab);
        });
    });

    window.switchTab = function (tab) {
        document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
        document.querySelector(`[data-tab="${tab}"]`)?.classList.add('active');

        document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        document.getElementById(`tab-${tab}`).classList.add('active');

        const titles = {
            'dashboard': 'Dashboard',
            'properties': 'Browse Properties',
            'inspections': 'My Inspections',
            'transactions': 'My Transactions',
            'feedback': 'My Feedback'
        };
        document.getElementById('pageTitle').textContent = titles[tab];

        currentTab = tab;
        loadTabData(tab);
    };

    async function loadTabData(tab) {
        switch (tab) {
            case 'dashboard': loadDashboard(); break;
            case 'properties': loadProperties(); break;
            case 'inspections': loadInspections(); break;
            case 'transactions': loadTransactions(); break;
            case 'feedback': loadFeedback(); break;
        }
    }

    async function loadDashboard() {
        try {
            const stats = await apiRequest('/client/dashboard');
            document.getElementById('statProperties').textContent = stats.availableProperties;
            document.getElementById('statInspections').textContent = stats.scheduledInspections;
            document.getElementById('statTransactions').textContent = stats.myTransactions;
            document.getElementById('statFeedback').textContent = stats.myFeedback;

            // Load featured properties
            const properties = await apiRequest('/client/properties');
            const featured = properties.filter(p => p.featured).slice(0, 4);

            if (featured.length === 0) {
                document.getElementById('featuredProperties').innerHTML = '<p class="text-muted">No featured properties</p>';
            } else {
                document.getElementById('featuredProperties').innerHTML = featured.map(p => createPropertyCard(p)).join('');
            }
        } catch (error) {
            console.error('Error loading dashboard:', error);
        }
    }

    window.loadProperties = async function () {
        try {
            const type = document.getElementById('filterType')?.value || '';
            const property_for = document.getElementById('filterFor')?.value || '';
            const minPrice = document.getElementById('filterMinPrice')?.value || '';
            const maxPrice = document.getElementById('filterMaxPrice')?.value || '';

            let url = '/client/properties?';
            if (type) url += `type=${type}&`;
            if (property_for) url += `property_for=${property_for}&`;
            if (minPrice) url += `minPrice=${minPrice}&`;
            if (maxPrice) url += `maxPrice=${maxPrice}&`;

            const properties = await apiRequest(url);
            const grid = document.getElementById('propertiesGrid');

            if (properties.length === 0) {
                grid.innerHTML = '<p class="text-muted text-center p-4">No properties found matching your criteria</p>';
            } else {
                grid.innerHTML = properties.map(p => createPropertyCard(p)).join('');
            }
        } catch (error) {
            console.error('Error loading properties:', error);
        }
    };

    function createPropertyCard(p) {
        const imageContent = p.image_url
            ? `<img src="${p.image_url}" alt="${p.title}" style="width:100%;height:100%;object-fit:cover;">`
            : `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
                    </svg>`;
        return `
            <div class="property-card">
                <div class="property-image">
                    ${imageContent}
                    ${p.featured ? '<span class="property-badge featured">Featured</span>' : `<span class="property-badge">${p.property_for}</span>`}
                </div>
                <div class="property-content">
                    <h3 class="property-title">${p.title}</h3>
                    <div class="property-location">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/>
                        </svg>
                        <span>${p.area}, ${p.city}</span>
                    </div>
                    <div class="property-price">${formatCurrency(p.listing_price)}</div>
                    <div class="property-features">
                        ${p.bedrooms ? `<span class="property-feature">🛏️ ${p.bedrooms}</span>` : ''}
                        ${p.bathrooms ? `<span class="property-feature">🚿 ${p.bathrooms}</span>` : ''}
                        ${p.area_sqft ? `<span class="property-feature">📐 ${p.area_sqft} sqft</span>` : ''}
                    </div>
                    <div class="flex gap-2 mt-3">
                        <button class="btn btn-primary btn-sm" onclick="viewProperty(${p.listing_id})">View Details</button>
                        <button class="btn btn-secondary btn-sm" onclick="bookInspection(${p.listing_id}, '${p.title}')">Book Visit</button>
                    </div>
                </div>
            </div>
        `;
    }

    window.viewProperty = async function (listingId) {
        try {
            const p = await apiRequest(`/client/properties/${listingId}`);
            document.getElementById('modalTitle').textContent = p.title;
            document.getElementById('modalBody').innerHTML = `
                <div class="property-image" style="height: 200px; border-radius: var(--radius-lg); margin-bottom: 1rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
                    </svg>
                </div>
                <div class="property-price" style="font-size: 2rem; margin-bottom: 1rem;">${formatCurrency(p.listing_price)}</div>
                <div class="property-features mb-3">
                    ${p.bedrooms ? `<span class="property-feature">🛏️ ${p.bedrooms} Bedrooms</span>` : ''}
                    ${p.bathrooms ? `<span class="property-feature">🚿 ${p.bathrooms} Bathrooms</span>` : ''}
                    ${p.area_sqft ? `<span class="property-feature">📐 ${p.area_sqft} sqft</span>` : ''}
                </div>
                <p><strong>Type:</strong> ${p.type_name}</p>
                <p><strong>Location:</strong> ${p.address}, ${p.area}, ${p.city}</p>
                <p><strong>For:</strong> ${p.property_for}</p>
                ${p.year_built ? `<p><strong>Year Built:</strong> ${p.year_built}</p>` : ''}
                <p class="mt-2">${p.description || p.listing_description || 'No description available.'}</p>
                <hr style="margin: 1.5rem 0; border-color: var(--border-color);">
                <p><strong>Agent:</strong> ${p.agent_name}</p>
                <p><strong>Phone:</strong> ${p.agent_phone || 'Not available'}</p>
                <p><strong>Email:</strong> ${p.agent_email || 'Not available'}</p>
                <div class="flex gap-2 mt-3">
                    <button class="btn btn-primary" onclick="bookInspection(${p.listing_id}, '${p.title}')">Book Inspection</button>
                    <button class="btn btn-secondary" onclick="submitFeedback(${p.listing_id}, '${p.title}')">Give Feedback</button>
                </div>
            `;
            document.getElementById('modal').classList.add('active');
        } catch (error) {
            alert('Error loading property details');
        }
    };

    window.bookInspection = function (listingId, title) {
        document.getElementById('modalTitle').textContent = 'Book Inspection';
        document.getElementById('modalBody').innerHTML = `
            <p class="mb-3">Schedule a visit for: <strong>${title}</strong></p>
            <form id="inspectionForm" onsubmit="submitInspection(event, ${listingId})">
                <div class="form-group">
                    <label class="form-label">Preferred Date</label>
                    <input type="date" name="inspection_date" class="form-input" required min="${new Date().toISOString().split('T')[0]}">
                </div>
                <div class="form-group">
                    <label class="form-label">Preferred Time</label>
                    <input type="time" name="inspection_time" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Notes (optional)</label>
                    <textarea name="notes" class="form-textarea" placeholder="Any specific requirements..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary w-full">Book Inspection</button>
            </form>
        `;
        document.getElementById('modal').classList.add('active');
    };

    window.submitInspection = async function (e, listingId) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = {
            listing_id: listingId,
            inspection_date: formData.get('inspection_date'),
            inspection_time: formData.get('inspection_time'),
            notes: formData.get('notes')
        };

        try {
            await apiRequest('/client/inspections', { method: 'POST', body: JSON.stringify(data) });
            closeModal();
            alert('Inspection booked successfully!');
            loadInspections();
        } catch (error) {
            alert('Error: ' + error.message);
        }
    };

    window.submitFeedback = function (listingId, title) {
        document.getElementById('modalTitle').textContent = 'Submit Feedback';
        document.getElementById('modalBody').innerHTML = `
            <p class="mb-3">Your feedback for: <strong>${title}</strong></p>
            <form id="feedbackForm" onsubmit="saveFeedback(event, ${listingId})">
                <div class="form-group">
                    <label class="form-label">Rating</label>
                    <select name="rating" class="form-select" required>
                        <option value="5">⭐⭐⭐⭐⭐ Excellent</option>
                        <option value="4">⭐⭐⭐⭐ Very Good</option>
                        <option value="3">⭐⭐⭐ Good</option>
                        <option value="2">⭐⭐ Fair</option>
                        <option value="1">⭐ Poor</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Comment</label>
                    <textarea name="comment" class="form-textarea" placeholder="Share your experience..." required></textarea>
                </div>
                <button type="submit" class="btn btn-primary w-full">Submit Feedback</button>
            </form>
        `;
        document.getElementById('modal').classList.add('active');
    };

    window.saveFeedback = async function (e, listingId) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = {
            listing_id: listingId,
            rating: parseInt(formData.get('rating')),
            comment: formData.get('comment')
        };

        try {
            await apiRequest('/client/feedback', { method: 'POST', body: JSON.stringify(data) });
            closeModal();
            alert('Feedback submitted successfully!');
            loadFeedback();
        } catch (error) {
            alert('Error: ' + error.message);
        }
    };

    async function loadInspections() {
        try {
            const inspections = await apiRequest('/client/inspections');
            const tbody = document.getElementById('inspectionsTable');
            if (inspections.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="text-center">No inspections booked yet</td></tr>';
            } else {
                tbody.innerHTML = inspections.map(i => `
                    <tr>
                        <td>${i.property_title}</td>
                        <td>${i.address}</td>
                        <td>${i.agent_name}</td>
                        <td>${formatDate(i.inspection_date)}</td>
                        <td>${i.inspection_time}</td>
                        <td><span class="badge badge-${getStatusBadge(i.status)}">${i.status}</span></td>
                        <td>
                            ${i.status === 'Scheduled' ? `<button class="btn btn-sm btn-danger" onclick="cancelInspection(${i.inspection_id})">Cancel</button>` : '-'}
                        </td>
                    </tr>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading inspections:', error);
        }
    }

    window.cancelInspection = async function (id) {
        if (!confirm('Are you sure you want to cancel this inspection?')) return;
        try {
            await apiRequest(`/client/inspections/${id}/cancel`, { method: 'PUT' });
            loadInspections();
        } catch (error) {
            alert('Error: ' + error.message);
        }
    };

    async function loadTransactions() {
        try {
            const transactions = await apiRequest('/client/transactions');
            const tbody = document.getElementById('transactionsTable');
            if (transactions.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center">No transactions yet</td></tr>';
            } else {
                tbody.innerHTML = transactions.map(t => `
                    <tr>
                        <td>${t.property_title}</td>
                        <td>${t.address}</td>
                        <td><span class="badge badge-info">${t.transaction_type}</span></td>
                        <td>${formatCurrency(t.amount)}</td>
                        <td>${formatDate(t.transaction_date)}</td>
                        <td><span class="badge badge-${getStatusBadge(t.status)}">${t.status}</span></td>
                    </tr>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading transactions:', error);
        }
    }

    async function loadFeedback() {
        try {
            const feedback = await apiRequest('/client/feedback');
            const tbody = document.getElementById('feedbackTable');
            if (feedback.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" class="text-center">No feedback submitted yet</td></tr>';
            } else {
                tbody.innerHTML = feedback.map(f => `
                    <tr>
                        <td>${f.property_title}</td>
                        <td>${'⭐'.repeat(f.rating)}</td>
                        <td>${f.comment || '-'}</td>
                        <td>${formatDate(f.feedback_date)}</td>
                    </tr>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading feedback:', error);
        }
    }

    function getStatusBadge(status) {
        const map = {
            'Available': 'success', 'Active': 'success', 'Completed': 'success',
            'Pending': 'warning', 'Scheduled': 'warning',
            'Cancelled': 'danger'
        };
        return map[status] || 'primary';
    }

    window.closeModal = function () {
        document.getElementById('modal').classList.remove('active');
    };

    // Load property types for filter
    async function loadPropertyTypes() {
        try {
            const types = await apiRequest('/client/property-types');
            const select = document.getElementById('filterType');
            if (select) {
                types.forEach(t => {
                    select.innerHTML += `<option value="${t.type_id}">${t.type_name}</option>`;
                });
                // Add change listener to auto-filter
                select.addEventListener('change', () => loadProperties());
            }
        } catch (error) {
            console.error('Error loading property types:', error);
        }
    }

    // Add change listeners for other filters
    function setupFilterListeners() {
        const filterFor = document.getElementById('filterFor');
        if (filterFor) {
            filterFor.addEventListener('change', () => loadProperties());
        }
    }

    // Initial load
    loadDashboard();
    loadPropertyTypes();
    setupFilterListeners();
})();
