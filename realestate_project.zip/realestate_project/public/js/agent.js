// Agent Dashboard JavaScript - Full CRUD Operations
(function () {
    if (!requireAuth(['agent'])) return;

    const user = Auth.getUser();
    document.getElementById('userName').textContent = user?.name || 'Agent';

    let currentTab = 'dashboard';
    let editingId = null;
    let propertyTypes = [];
    let locations = [];
    let myProperties = [];

    // Load helper data on init
    async function loadHelperData() {
        try {
            propertyTypes = await apiRequest('/agent/property-types');
            locations = await apiRequest('/agent/locations');
        } catch (e) {
            console.error('Error loading helper data:', e);
        }
    }
    loadHelperData();

    // Tab navigation
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tab = e.target.getAttribute('data-tab');
            if (tab) switchTab(tab);
        });
    });

    function switchTab(tab) {
        document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
        const activeLink = document.querySelector(`[data-tab="${tab}"]`);
        if (activeLink) activeLink.classList.add('active');

        document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        const tabPanel = document.getElementById(`tab-${tab}`);
        if (tabPanel) tabPanel.classList.add('active');

        const titles = {
            'dashboard': 'Dashboard',
            'properties': 'My Properties',
            'listings': 'My Listings',
            'inspections': 'Inspections',
            'feedback': 'Client Feedback'
        };
        document.getElementById('pageTitle').textContent = titles[tab];

        const addBtn = document.getElementById('addNewBtn');
        if (['properties', 'listings'].includes(tab)) {
            addBtn.style.display = 'block';
            addBtn.onclick = () => showAddModal(tab);
        } else {
            addBtn.style.display = 'none';
        }

        currentTab = tab;
        loadTabData(tab);
    }

    async function loadTabData(tab) {
        switch (tab) {
            case 'dashboard': loadDashboard(); break;
            case 'properties': loadProperties(); break;
            case 'listings': loadListings(); break;
            case 'inspections': loadInspections(); break;
            case 'feedback': loadFeedback(); break;
        }
    }

    async function loadDashboard() {
        try {
            const stats = await apiRequest('/agent/dashboard');
            document.getElementById('statProperties').textContent = stats.myProperties || 0;
            document.getElementById('statListings').textContent = stats.activeListings || 0;
            document.getElementById('statInspections').textContent = stats.scheduledInspections || 0;
            document.getElementById('statCommission').textContent = formatCurrency(stats.totalCommission);

            // Load upcoming inspections
            const inspections = await apiRequest('/agent/inspections');
            const upcoming = inspections.filter(i => i.status === 'Scheduled').slice(0, 5);

            if (upcoming.length === 0) {
                document.getElementById('upcomingInspections').innerHTML = '<p class="text-muted">No upcoming inspections</p>';
            } else {
                document.getElementById('upcomingInspections').innerHTML = upcoming.map(i => `
                    <div class="card mb-2" style="padding: 1rem;">
                        <div class="flex justify-between items-center">
                            <div>
                                <strong>${i.property_title}</strong><br>
                                <span class="text-muted">${i.client_name} - ${i.client_phone || 'No phone'}</span>
                            </div>
                            <div class="text-right">
                                <span class="badge badge-warning">${formatDate(i.inspection_date)}</span><br>
                                <span class="text-muted">${i.inspection_time}</span>
                            </div>
                        </div>
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading dashboard:', error);
        }
    }

    async function loadProperties() {
        try {
            const properties = await apiRequest('/agent/properties');
            myProperties = properties;
            const tbody = document.getElementById('propertiesTable');
            if (properties.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="text-center">No properties found. Click "+ Add New" to add your first property.</td></tr>';
            } else {
                tbody.innerHTML = properties.map(p => `
                    <tr>
                        <td>${p.property_id}</td>
                        <td><strong>${p.title}</strong></td>
                        <td>${p.type_name || '-'}</td>
                        <td>${p.area || '-'}, ${p.city || '-'}</td>
                        <td>${formatCurrency(p.price)}</td>
                        <td><span class="badge badge-${getStatusBadge(p.status)}">${p.status}</span></td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-secondary" onclick="editProperty(${p.property_id})">Edit</button>
                            <button class="btn btn-sm btn-primary" onclick="createListingFromProperty(${p.property_id}, '${p.title}', ${p.price})">List</button>
                            <button class="btn btn-sm btn-danger" onclick="deleteProperty(${p.property_id})">Delete</button>
                        </td>
                    </tr>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading properties:', error);
            showAlert('Error loading properties: ' + error.message, 'danger');
        }
    }

    async function loadListings() {
        try {
            const listings = await apiRequest('/agent/listings');
            const tbody = document.getElementById('listingsTable');
            if (listings.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="text-center">No listings found. Add a property first, then create a listing.</td></tr>';
            } else {
                tbody.innerHTML = listings.map(l => `
                    <tr>
                        <td>${l.listing_id}</td>
                        <td>${l.property_title || '-'}</td>
                        <td>${formatCurrency(l.listing_price)}</td>
                        <td><span class="badge badge-${getStatusBadge(l.listing_status)}">${l.listing_status}</span></td>
                        <td>${l.views_count || 0}</td>
                        <td>${l.featured ? '⭐' : '-'}</td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-secondary" onclick="editListing(${l.listing_id})">Edit</button>
                        </td>
                    </tr>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading listings:', error);
            showAlert('Error loading listings: ' + error.message, 'danger');
        }
    }

    async function loadInspections() {
        try {
            const inspections = await apiRequest('/agent/inspections');
            const tbody = document.getElementById('inspectionsTable');
            if (inspections.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="text-center">No inspections found</td></tr>';
            } else {
                tbody.innerHTML = inspections.map(i => `
                    <tr>
                        <td>${i.inspection_id}</td>
                        <td>${i.property_title}</td>
                        <td>${i.client_name}</td>
                        <td>${i.client_phone || '-'}</td>
                        <td>${formatDate(i.inspection_date)}</td>
                        <td>${i.inspection_time}</td>
                        <td><span class="badge badge-${getStatusBadge(i.status)}">${i.status}</span></td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-secondary" onclick="updateInspection(${i.inspection_id}, '${i.status}')">Update</button>
                        </td>
                    </tr>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading inspections:', error);
        }
    }

    async function loadFeedback() {
        try {
            const feedback = await apiRequest('/agent/feedback');
            const tbody = document.getElementById('feedbackTable');
            if (feedback.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="text-center">No feedback found</td></tr>';
            } else {
                tbody.innerHTML = feedback.map(f => `
                    <tr>
                        <td>${f.property_title}</td>
                        <td>${f.client_name}</td>
                        <td>${'⭐'.repeat(f.rating)}</td>
                        <td>${f.comment || '-'}</td>
                        <td>${formatDate(f.feedback_date)}</td>
                    </tr>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading feedback:', error);
        }
    }

    function getStatusBadge(status) {
        const map = {
            'Available': 'success', 'Active': 'success', 'Completed': 'success',
            'Sold': 'info', 'Rented': 'info',
            'Pending': 'warning', 'Scheduled': 'warning',
            'Inactive': 'danger', 'Cancelled': 'danger', 'No-Show': 'danger'
        };
        return map[status] || 'primary';
    }

    function showAlert(message, type = 'success') {
        const container = document.getElementById('alertContainer');
        if (container) {
            container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
            setTimeout(() => container.innerHTML = '', 4000);
        }
    }

    // =============================================
    // MODAL FUNCTIONS
    // =============================================

    window.showAddModal = async function (type) {
        editingId = null;

        if (type === 'properties') {
            document.getElementById('modalTitle').textContent = 'Add New Property';
            document.getElementById('modalBody').innerHTML = getPropertyForm(null);
        } else if (type === 'listings') {
            // Check if there are properties to list
            if (myProperties.length === 0) {
                await loadProperties();
            }
            if (myProperties.length === 0) {
                showAlert('You need to add a property first before creating a listing.', 'warning');
                return;
            }
            document.getElementById('modalTitle').textContent = 'Create New Listing';
            document.getElementById('modalBody').innerHTML = getListingForm(null);
        }

        document.getElementById('modal').classList.add('active');
    };

    window.editProperty = async function (id) {
        editingId = id;
        try {
            // Find property in loaded data or fetch it
            let property = myProperties.find(p => p.property_id === id);
            if (!property) {
                const properties = await apiRequest('/agent/properties');
                property = properties.find(p => p.property_id === id);
            }

            if (!property) {
                showAlert('Property not found', 'danger');
                return;
            }

            document.getElementById('modalTitle').textContent = 'Edit Property';
            document.getElementById('modalBody').innerHTML = getPropertyForm(property);
            document.getElementById('modal').classList.add('active');
        } catch (error) {
            showAlert('Error loading property: ' + error.message, 'danger');
        }
    };

    window.editListing = async function (id) {
        editingId = id;
        try {
            const listings = await apiRequest('/agent/listings');
            const listing = listings.find(l => l.listing_id === id);

            if (!listing) {
                showAlert('Listing not found', 'danger');
                return;
            }

            document.getElementById('modalTitle').textContent = 'Edit Listing';
            document.getElementById('modalBody').innerHTML = getListingForm(listing);
            document.getElementById('modal').classList.add('active');
        } catch (error) {
            showAlert('Error loading listing: ' + error.message, 'danger');
        }
    };

    window.createListingFromProperty = function (propertyId, title, price) {
        editingId = null;
        document.getElementById('modalTitle').textContent = 'Create Listing for ' + title;
        document.getElementById('modalBody').innerHTML = `
            <input type="hidden" name="property_id" value="${propertyId}">
            <div class="form-group">
                <label class="form-label">Property</label>
                <input class="form-input" value="${title}" disabled>
            </div>
            <div class="form-group">
                <label class="form-label">Listing Price (PKR) *</label>
                <input name="listing_price" type="number" class="form-input" value="${price}" required>
            </div>
            <div class="form-group">
                <label class="form-label">Listing Date</label>
                <input name="listing_date" type="date" class="form-input" value="${new Date().toISOString().split('T')[0]}">
            </div>
            <div class="form-group">
                <label class="form-label">Expiry Date</label>
                <input name="expiry_date" type="date" class="form-input">
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-textarea" placeholder="Listing description..."></textarea>
            </div>
            <div class="form-group">
                <label class="form-label"><input type="checkbox" name="featured"> Featured Listing</label>
            </div>
        `;
        currentTab = 'listings-new';
        document.getElementById('modal').classList.add('active');
    };

    function getPropertyForm(data) {
        const typeOptions = propertyTypes.map(t =>
            `<option value="${t.type_id}" ${data?.type_id == t.type_id ? 'selected' : ''}>${t.type_name}</option>`
        ).join('');

        const locationOptions = locations.map(l =>
            `<option value="${l.location_id}" ${data?.location_id == l.location_id ? 'selected' : ''}>${l.address}, ${l.area}</option>`
        ).join('');

        return `
            <div class="form-group">
                <label class="form-label">Title *</label>
                <input name="title" class="form-input" value="${data?.title || ''}" required placeholder="e.g., Beautiful 5-Bedroom House">
            </div>
            <div class="form-group">
                <label class="form-label">Property Type *</label>
                <select name="type_id" class="form-select" required>
                    <option value="">Select Type</option>
                    ${typeOptions}
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Location *</label>
                <select name="location_id" class="form-select" required>
                    <option value="">Select Location</option>
                    ${locationOptions}
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Price (PKR) *</label>
                <input name="price" type="number" class="form-input" value="${data?.price || ''}" required placeholder="e.g., 50000000">
            </div>
            <div class="form-group">
                <label class="form-label">Area (sqft)</label>
                <input name="area_sqft" type="number" class="form-input" value="${data?.area_sqft || ''}" placeholder="e.g., 4500">
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">Bedrooms</label>
                    <input name="bedrooms" type="number" class="form-input" value="${data?.bedrooms || 0}">
                </div>
                <div class="form-group">
                    <label class="form-label">Bathrooms</label>
                    <input name="bathrooms" type="number" class="form-input" value="${data?.bathrooms || 0}">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Year Built</label>
                <input name="year_built" type="number" class="form-input" value="${data?.year_built || ''}" placeholder="e.g., 2020">
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="Available" ${data?.status === 'Available' ? 'selected' : ''}>Available</option>
                        <option value="Pending" ${data?.status === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Sold" ${data?.status === 'Sold' ? 'selected' : ''}>Sold</option>
                        <option value="Rented" ${data?.status === 'Rented' ? 'selected' : ''}>Rented</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">For</label>
                    <select name="property_for" class="form-select">
                        <option value="Sale" ${data?.property_for === 'Sale' ? 'selected' : ''}>Sale</option>
                        <option value="Rent" ${data?.property_for === 'Rent' ? 'selected' : ''}>Rent</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-textarea" placeholder="Property description...">${data?.description || ''}</textarea>
            </div>
        `;
    }

    function getListingForm(data) {
        const propertyOptions = myProperties.map(p =>
            `<option value="${p.property_id}" ${data?.property_id == p.property_id ? 'selected' : ''}>${p.title} - ${formatCurrency(p.price)}</option>`
        ).join('');

        return `
            ${!data ? `
            <div class="form-group">
                <label class="form-label">Property *</label>
                <select name="property_id" class="form-select" required>
                    <option value="">Select Property</option>
                    ${propertyOptions}
                </select>
            </div>` : `
            <div class="form-group">
                <label class="form-label">Property</label>
                <input class="form-input" value="${data.property_title}" disabled>
            </div>`}
            <div class="form-group">
                <label class="form-label">Listing Price (PKR) *</label>
                <input name="listing_price" type="number" class="form-input" value="${data?.listing_price || ''}" required>
            </div>
            <div class="form-group">
                <label class="form-label">Listing Date</label>
                <input name="listing_date" type="date" class="form-input" value="${data?.listing_date ? data.listing_date.split('T')[0] : new Date().toISOString().split('T')[0]}">
            </div>
            <div class="form-group">
                <label class="form-label">Expiry Date</label>
                <input name="expiry_date" type="date" class="form-input" value="${data?.expiry_date ? data.expiry_date.split('T')[0] : ''}">
            </div>
            ${data ? `
            <div class="form-group">
                <label class="form-label">Status</label>
                <select name="listing_status" class="form-select">
                    <option value="Active" ${data?.listing_status === 'Active' ? 'selected' : ''}>Active</option>
                    <option value="Inactive" ${data?.listing_status === 'Inactive' ? 'selected' : ''}>Inactive</option>
                    <option value="Sold" ${data?.listing_status === 'Sold' ? 'selected' : ''}>Sold</option>
                    <option value="Expired" ${data?.listing_status === 'Expired' ? 'selected' : ''}>Expired</option>
                </select>
            </div>` : ''}
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-textarea" placeholder="Listing description...">${data?.description || ''}</textarea>
            </div>
            <div class="form-group">
                <label class="form-label"><input type="checkbox" name="featured" ${data?.featured ? 'checked' : ''}> Featured Listing</label>
            </div>
        `;
    }

    window.closeModal = function () {
        document.getElementById('modal').classList.remove('active');
        editingId = null;
    };

    window.handleFormSubmit = async function (e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());

        // Convert checkbox values
        data.featured = formData.has('featured');

        try {
            if (currentTab === 'properties' || (currentTab === 'dashboard' && editingId)) {
                if (editingId) {
                    await apiRequest(`/agent/properties/${editingId}`, { method: 'PUT', body: JSON.stringify(data) });
                    showAlert('Property updated successfully!', 'success');
                } else {
                    await apiRequest('/agent/properties', { method: 'POST', body: JSON.stringify(data) });
                    showAlert('Property added successfully!', 'success');
                }
                closeModal();
                loadProperties();
            } else if (currentTab === 'listings' || currentTab === 'listings-new') {
                if (editingId) {
                    await apiRequest(`/agent/listings/${editingId}`, { method: 'PUT', body: JSON.stringify(data) });
                    showAlert('Listing updated successfully!', 'success');
                } else {
                    await apiRequest('/agent/listings', { method: 'POST', body: JSON.stringify(data) });
                    showAlert('Listing created successfully!', 'success');
                }
                closeModal();
                currentTab = 'listings';
                loadListings();
            }
        } catch (error) {
            showAlert('Error: ' + error.message, 'danger');
        }
    };

    window.updateInspection = async function (id, currentStatus) {
        editingId = id;
        document.getElementById('modalTitle').textContent = 'Update Inspection';
        document.getElementById('modalBody').innerHTML = `
            <div class="form-group">
                <label class="form-label">Status</label>
                <select name="status" class="form-select" id="inspectionStatus">
                    <option value="Scheduled" ${currentStatus === 'Scheduled' ? 'selected' : ''}>Scheduled</option>
                    <option value="Completed" ${currentStatus === 'Completed' ? 'selected' : ''}>Completed</option>
                    <option value="Cancelled" ${currentStatus === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                    <option value="No-Show" ${currentStatus === 'No-Show' ? 'selected' : ''}>No-Show</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Your Feedback</label>
                <textarea name="agent_feedback" class="form-textarea" placeholder="Add notes about the inspection..."></textarea>
            </div>
        `;
        document.getElementById('modal').classList.add('active');

        document.getElementById('modalForm').onsubmit = async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData.entries());
            try {
                await apiRequest(`/agent/inspections/${id}`, { method: 'PUT', body: JSON.stringify(data) });
                showAlert('Inspection updated successfully!', 'success');
                closeModal();
                loadInspections();
            } catch (error) {
                showAlert('Error: ' + error.message, 'danger');
            }
        };
    };

    window.deleteProperty = async function (id) {
        if (!confirm('Are you sure you want to delete this property? This will also delete any associated listings.')) return;
        try {
            await apiRequest(`/agent/properties/${id}`, { method: 'DELETE' });
            showAlert('Property deleted successfully!', 'success');
            loadProperties();
        } catch (error) {
            showAlert('Error: ' + error.message, 'danger');
        }
    };

    // Initial load
    loadDashboard();
})();
