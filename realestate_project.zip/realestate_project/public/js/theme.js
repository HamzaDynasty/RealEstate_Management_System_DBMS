// Theme Management
(function () {
    const THEME_KEY = 'real-estate-theme';

    // Get stored theme or default to light
    function getStoredTheme() {
        return localStorage.getItem(THEME_KEY) || 'light';
    }

    // Set theme
    function setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem(THEME_KEY, theme);
        updateToggleIcons(theme);
    }

    // Update toggle button icons
    function updateToggleIcons(theme) {
        // Update all theme toggle buttons
        const toggleBtns = document.querySelectorAll('.theme-toggle, .theme-btn, #themeBtn');
        toggleBtns.forEach(btn => {
            const svg = btn.querySelector('svg');
            if (svg) {
                if (theme === 'dark') {
                    svg.innerHTML = `<path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/>`;
                } else {
                    svg.innerHTML = `<path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>`;
                }
            }
        });
    }

    // Toggle theme
    function toggleTheme() {
        const currentTheme = getStoredTheme();
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        setTheme(newTheme);
    }

    // Initialize theme on page load
    function initTheme() {
        const theme = getStoredTheme();
        setTheme(theme);

        // Add click handlers to all theme toggle buttons
        const toggleBtns = document.querySelectorAll('.theme-toggle, .theme-btn, #themeBtn');
        toggleBtns.forEach(btn => {
            btn.removeEventListener('click', toggleTheme);
            btn.addEventListener('click', toggleTheme);
        });
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initTheme);
    } else {
        initTheme();
    }

    // Also run after a short delay to catch dynamically loaded elements
    setTimeout(initTheme, 100);

    // Expose to global scope
    window.toggleTheme = toggleTheme;
    window.setTheme = setTheme;
})();
