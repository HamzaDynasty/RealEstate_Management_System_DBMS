// Admin Dashboard JavaScript - Full CRUD Operations with Search & Filters
(function () {
    // Check authentication
    const token = localStorage.getItem('token');
    const user = JSON.parse(localStorage.getItem('user') || '{}');

    if (!token || user.role !== 'admin') {
        window.location.href = '/login';
        return;
    }

    document.getElementById('userName').textContent = user.name || 'Admin';

    let currentTab = 'dashboard';
    let editingId = null;
    let allData = {}; // Store data for search/filter

    // API helper
    async function api(endpoint, method = 'GET', body = null) {
        const options = {
            method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        };
        if (body) options.body = JSON.stringify(body);

        const response = await fetch(`/api/admin${endpoint}`, options);
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Request failed');
        }
        return response.json();
    }

    function formatCurrency(amount) {
        return 'PKR ' + new Intl.NumberFormat('en-PK').format(amount || 0);
    }

    function formatDate(date) {
        if (!date) return '-';
        return new Date(date).toLocaleDateString('en-PK');
    }

    function showAlert(message, type = 'success') {
        const container = document.getElementById('alertContainer');
        container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
        setTimeout(() => container.innerHTML = '', 4000);
    }

    // Search functionality
    window.handleSearch = function (event) {
        const searchTerm = event.target.value.toLowerCase();
        filterTableData(searchTerm);
    };

    // Update agent display when listing is selected in transaction form
    window.updateAgentFromListing = function (selectElement) {
        const listingId = selectElement.value;
        const agentField = document.getElementById('agentDisplayField');
        if (!agentField) return;

        if (!listingId || !window._listingsData) {
            agentField.value = '';
            return;
        }

        const selectedListing = window._listingsData.find(l => l.listing_id == listingId);
        if (selectedListing) {
            agentField.value = selectedListing.agent_name || 'N/A';
        } else {
            agentField.value = '';
        }
    };

    function filterTableData(searchTerm) {
        const tableId = getTableIdForTab(currentTab);
        if (!tableId || !allData[currentTab]) return;

        const filtered = allData[currentTab].filter(item => {
            return Object.values(item).some(val =>
                String(val).toLowerCase().includes(searchTerm)
            );
        });
        renderTableData(currentTab, filtered);
    }

    function getTableIdForTab(tab) {
        const tableMap = {
            'agencies': 'agenciesTable',
            'agents': 'agentsTable',
            'clients': 'clientsTable',
            'properties': 'propertiesTable',
            'listings': 'listingsTable',
            'transactions': 'transactionsTable',
            'payments': 'paymentsTable',
            'contracts': 'contractsTable',
            'inspections': 'inspectionsTable',
            'feedback': 'feedbackTable',
            'locations': 'locationsTable',
            'property-types': 'propertyTypesTable'
        };
        return tableMap[tab];
    }

    // Tab navigation - make switchTab globally available
    window.switchTab = function (tab) {
        document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
        const activeLink = document.querySelector(`[data-tab="${tab}"]`);
        if (activeLink) activeLink.classList.add('active');

        document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        const tabPanel = document.getElementById(`tab-${tab}`);
        if (tabPanel) tabPanel.classList.add('active');

        const titles = {
            'dashboard': 'Dashboard',
            'agencies': 'Agencies',
            'agents': 'Agents',
            'clients': 'Clients',
            'properties': 'Properties',
            'listings': 'Listings',
            'transactions': 'Transactions',
            'payments': 'Payments',
            'contracts': 'Contracts',
            'inspections': 'Inspections',
            'feedback': 'Feedback',
            'locations': 'Locations',
            'property-types': 'Property Types'
        };
        document.getElementById('pageTitle').textContent = titles[tab] || tab;

        // Show/hide add button and search
        const addBtn = document.getElementById('addNewBtn');
        const searchContainer = document.getElementById('searchContainer');
        const tabsWithAdd = ['agencies', 'agents', 'clients', 'properties', 'locations', 'property-types', 'listings', 'transactions', 'payments', 'contracts', 'inspections'];
        const tabsWithSearch = ['agencies', 'agents', 'clients', 'properties', 'listings', 'transactions', 'payments', 'contracts', 'inspections', 'feedback', 'locations', 'property-types'];

        if (tabsWithAdd.includes(tab)) {
            addBtn.style.display = 'block';
            addBtn.onclick = () => showAddModal(tab);
        } else {
            addBtn.style.display = 'none';
        }

        if (tabsWithSearch.includes(tab)) {
            searchContainer.style.display = 'block';
            document.getElementById('searchInput').value = '';
        } else {
            searchContainer.style.display = 'none';
        }

        currentTab = tab;
        loadTabData(tab);
    }

    async function loadTabData(tab) {
        try {
            switch (tab) {
                case 'dashboard': await loadDashboard(); break;
                case 'agencies': await loadAgencies(); break;
                case 'agents': await loadAgents(); break;
                case 'clients': await loadClients(); break;
                case 'properties': await loadProperties(); break;
                case 'listings': await loadListings(); break;
                case 'transactions': await loadTransactions(); break;
                case 'payments': await loadPayments(); break;
                case 'contracts': await loadContracts(); break;
                case 'inspections': await loadInspections(); break;
                case 'feedback': await loadFeedback(); break;
                case 'locations': await loadLocations(); break;
                case 'property-types': await loadPropertyTypes(); break;
            }
        } catch (error) {
            console.error('Error loading data:', error);
            showAlert('Error loading data: ' + error.message, 'danger');
        }
    }

    async function loadDashboard() {
        try {
            const stats = await api('/dashboard');
            document.getElementById('statProperties').textContent = stats.properties || 0;
            document.getElementById('statAgents').textContent = stats.agents || 0;
            document.getElementById('statClients').textContent = stats.clients || 0;
            document.getElementById('statListings').textContent = stats.activeListings || 0;
            document.getElementById('statSales').textContent = formatCurrency(stats.totalSales);
            document.getElementById('statContracts').textContent = stats.activeContracts || 0;
            document.getElementById('statSold').textContent = stats.propertiesSold || 0;
            document.getElementById('statRented').textContent = stats.propertiesRented || 0;

            // Load sales report
            const salesReport = await api('/reports/sales-by-agent');
            const tbody = document.getElementById('salesReportTable');
            tbody.innerHTML = salesReport.map(r => `
                <tr>
                    <td>${r.agent_name}</td>
                    <td>${r.total_transactions || 0}</td>
                    <td>${formatCurrency(r.total_sales)}</td>
                    <td>${formatCurrency(r.total_commission)}</td>
                </tr>
            `).join('') || '<tr><td colspan="4" class="text-center">No data available</td></tr>';
        } catch (error) {
            console.error('Dashboard error:', error);
        }
    }

    async function loadAgencies() {
        const data = await api('/agencies');
        allData['agencies'] = data;
        renderAgencies(data);
    }

    function renderAgencies(data) {
        document.getElementById('agenciesTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.agency_id}</td>
                <td><strong>${r.agency_name}</strong></td>
                <td>${r.email}</td>
                <td>${r.phone || '-'}</td>
                <td>${r.license_number || '-'}</td>
                <td><span class="badge badge-${r.is_active ? 'success' : 'danger'}">${r.is_active ? 'Active' : 'Inactive'}</span></td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('agencies', ${r.agency_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('agencies', ${r.agency_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="7" class="text-center">No agencies found</td></tr>';
    }

    async function loadAgents() {
        const data = await api('/agents');
        allData['agents'] = data;
        renderAgents(data);
    }

    function renderAgents(data) {
        document.getElementById('agentsTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.agent_id}</td>
                <td><strong>${r.first_name} ${r.last_name}</strong></td>
                <td>${r.email}</td>
                <td>${r.phone || '-'}</td>
                <td>${r.agency_name || '-'}</td>
                <td>${r.commission_rate}%</td>
                <td><span class="badge badge-${r.is_active ? 'success' : 'danger'}">${r.is_active ? 'Active' : 'Inactive'}</span></td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('agents', ${r.agent_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('agents', ${r.agent_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="8" class="text-center">No agents found</td></tr>';
    }

    async function loadClients() {
        const data = await api('/clients');
        allData['clients'] = data;
        renderClients(data);
    }

    function renderClients(data) {
        document.getElementById('clientsTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.client_id}</td>
                <td><strong>${r.first_name} ${r.last_name}</strong></td>
                <td>${r.email}</td>
                <td>${r.phone || '-'}</td>
                <td><span class="badge badge-primary">${r.client_type}</span></td>
                <td>${r.cnic || '-'}</td>
                <td><span class="badge badge-${r.is_active ? 'success' : 'danger'}">${r.is_active ? 'Active' : 'Inactive'}</span></td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('clients', ${r.client_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('clients', ${r.client_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="8" class="text-center">No clients found</td></tr>';
    }

    async function loadProperties() {
        const data = await api('/properties');
        allData['properties'] = data;
        renderProperties(data);
    }

    function renderProperties(data) {
        document.getElementById('propertiesTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.property_id}</td>
                <td><strong>${r.title}</strong></td>
                <td><span class="badge badge-info">${r.type_name || '-'}</span></td>
                <td>${r.area || '-'}, ${r.city || '-'}</td>
                <td>${formatCurrency(r.price)}</td>
                <td><span class="badge badge-${r.status === 'Available' ? 'success' : r.status === 'Pending' ? 'warning' : 'info'}">${r.status}</span></td>
                <td>${r.agent_name || '-'}</td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('properties', ${r.property_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('properties', ${r.property_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="8" class="text-center">No properties found</td></tr>';
    }

    async function loadListings() {
        const data = await api('/listings');
        allData['listings'] = data;
        renderListings(data);
    }

    function renderListings(data) {
        document.getElementById('listingsTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.listing_id}</td>
                <td>${r.property_title || '-'}</td>
                <td>${r.agent_name || '-'}</td>
                <td>${formatCurrency(r.listing_price)}</td>
                <td><span class="badge badge-${r.listing_status === 'Active' ? 'success' : 'warning'}">${r.listing_status}</span></td>
                <td>${r.views_count}</td>
                <td>${r.featured ? '⭐' : '-'}</td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('listings', ${r.listing_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('listings', ${r.listing_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="8" class="text-center">No listings found</td></tr>';
    }

    async function loadTransactions() {
        const data = await api('/transactions');
        allData['transactions'] = data;
        renderTransactions(data);
    }

    function renderTransactions(data) {
        document.getElementById('transactionsTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.transaction_id}</td>
                <td>${r.property_title || '-'}</td>
                <td>${r.client_name || '-'}</td>
                <td>${r.agent_name || '-'}</td>
                <td><span class="badge badge-${r.transaction_type === 'Sale' ? 'primary' : 'info'}">${r.transaction_type}</span></td>
                <td>${formatCurrency(r.amount)}</td>
                <td>${formatCurrency(r.commission)}</td>
                <td><span class="badge badge-${r.status === 'Completed' ? 'success' : r.status === 'Pending' ? 'warning' : 'danger'}">${r.status}</span></td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('transactions', ${r.transaction_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('transactions', ${r.transaction_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="9" class="text-center">No transactions found</td></tr>';
    }

    async function loadPayments() {
        const data = await api('/payments');
        allData['payments'] = data;
        renderPayments(data);
    }

    function renderPayments(data) {
        document.getElementById('paymentsTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.payment_id}</td>
                <td>#${r.transaction_id}</td>
                <td>${formatCurrency(r.amount)}</td>
                <td>${r.payment_method}</td>
                <td><span class="badge badge-${r.payment_status === 'Completed' ? 'success' : 'warning'}">${r.payment_status}</span></td>
                <td>${r.reference_number || '-'}</td>
                <td>${formatDate(r.payment_date)}</td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('payments', ${r.payment_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('payments', ${r.payment_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="8" class="text-center">No payments found</td></tr>';
    }

    async function loadContracts() {
        const data = await api('/contracts');
        allData['contracts'] = data;
        renderContracts(data);
    }

    function renderContracts(data) {
        document.getElementById('contractsTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.contract_id}</td>
                <td>${r.property_title || '-'}</td>
                <td>${r.client_name || '-'}</td>
                <td><span class="badge badge-info">${r.contract_type}</span></td>
                <td>${formatDate(r.start_date)}</td>
                <td>${formatDate(r.end_date)}</td>
                <td><span class="badge badge-${r.status === 'Active' ? 'success' : r.status === 'Completed' ? 'info' : 'warning'}">${r.status}</span></td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('contracts', ${r.contract_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('contracts', ${r.contract_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="8" class="text-center">No contracts found</td></tr>';
    }

    async function loadInspections() {
        const data = await api('/inspections');
        allData['inspections'] = data;
        renderInspections(data);
    }

    function renderInspections(data) {
        document.getElementById('inspectionsTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.inspection_id}</td>
                <td>${r.property_title || '-'}</td>
                <td>${r.client_name || '-'}</td>
                <td>${r.agent_name || '-'}</td>
                <td>${formatDate(r.inspection_date)}</td>
                <td>${r.inspection_time || '-'}</td>
                <td><span class="badge badge-${r.status === 'Completed' ? 'success' : r.status === 'Scheduled' ? 'warning' : 'danger'}">${r.status}</span></td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('inspections', ${r.inspection_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="8" class="text-center">No inspections found</td></tr>';
    }

    async function loadFeedback() {
        const data = await api('/feedback');
        allData['feedback'] = data;
        renderFeedback(data);
    }

    function renderFeedback(data) {
        document.getElementById('feedbackTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.feedback_id}</td>
                <td>${r.property_title || '-'}</td>
                <td>${r.client_name || '-'}</td>
                <td>${'⭐'.repeat(r.rating)}</td>
                <td>${r.comment || '-'}</td>
                <td>${formatDate(r.feedback_date)}</td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('feedback', ${r.feedback_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="7" class="text-center">No feedback found</td></tr>';
    }

    async function loadLocations() {
        const data = await api('/locations');
        allData['locations'] = data;
        renderLocations(data);
    }

    function renderLocations(data) {
        document.getElementById('locationsTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.location_id}</td>
                <td>${r.address}</td>
                <td>${r.area || '-'}</td>
                <td>${r.city}</td>
                <td>${r.postal_code || '-'}</td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('locations', ${r.location_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('locations', ${r.location_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="6" class="text-center">No locations found</td></tr>';
    }

    async function loadPropertyTypes() {
        const data = await api('/property-types');
        allData['property-types'] = data;
        renderPropertyTypes(data);
    }

    function renderPropertyTypes(data) {
        document.getElementById('propertyTypesTable').innerHTML = data.map(r => `
            <tr>
                <td>${r.type_id}</td>
                <td><strong>${r.type_name}</strong></td>
                <td>${r.description || '-'}</td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-secondary" onclick="editItem('property-types', ${r.type_id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('property-types', ${r.type_id})">Delete</button>
                </td>
            </tr>
        `).join('') || '<tr><td colspan="4" class="text-center">No property types found</td></tr>';
    }

    // Render table data based on tab
    function renderTableData(tab, data) {
        switch (tab) {
            case 'agencies': renderAgencies(data); break;
            case 'agents': renderAgents(data); break;
            case 'clients': renderClients(data); break;
            case 'properties': renderProperties(data); break;
            case 'listings': renderListings(data); break;
            case 'transactions': renderTransactions(data); break;
            case 'payments': renderPayments(data); break;
            case 'contracts': renderContracts(data); break;
            case 'inspections': renderInspections(data); break;
            case 'feedback': renderFeedback(data); break;
            case 'locations': renderLocations(data); break;
            case 'property-types': renderPropertyTypes(data); break;
        }
    }

    // Modal functions
    window.showAddModal = async function (table) {
        editingId = null;
        document.getElementById('modalTitle').textContent = 'Add New ' + table.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
        document.getElementById('modalBody').innerHTML = await getFormFields(table, null);
        document.getElementById('modal').classList.add('active');
    };

    window.editItem = async function (table, id) {
        editingId = id;
        try {
            const data = await api(`/${table}/${id}`);
            document.getElementById('modalTitle').textContent = 'Edit ' + table.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
            document.getElementById('modalBody').innerHTML = await getFormFields(table, data);
            document.getElementById('modal').classList.add('active');
        } catch (error) {
            showAlert('Error loading item: ' + error.message, 'danger');
        }
    };

    window.deleteItem = async function (table, id) {
        if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) return;
        try {
            await api(`/${table}/${id}`, 'DELETE');
            showAlert('Deleted successfully!', 'success');
            loadTabData(currentTab);
        } catch (error) {
            showAlert('Error deleting: ' + error.message, 'danger');
        }
    };

    window.closeModal = function () {
        document.getElementById('modal').classList.remove('active');
        editingId = null;
    };

    window.handleFormSubmit = async function (e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());

        // Convert checkbox values
        for (const key in data) {
            if (data[key] === 'on') data[key] = true;
            if (data[key] === '') delete data[key];
        }

        try {
            if (editingId) {
                await api(`/${currentTab}/${editingId}`, 'PUT', data);
                showAlert('Updated successfully!', 'success');
            } else {
                await api(`/${currentTab}`, 'POST', data);
                showAlert('Added successfully!', 'success');
            }
            closeModal();
            loadTabData(currentTab);
        } catch (error) {
            showAlert('Error: ' + error.message, 'danger');
        }
    };

    async function getFormFields(table, data) {
        let agencyOptions = '';
        let agentOptions = '';
        let propertyTypeOptions = '';
        let locationOptions = '';
        let clientOptions = '';
        let listingOptions = '';
        let transactionOptions = '';

        // Load dropdown data if needed
        try {
            if (['agents', 'properties'].includes(table)) {
                const agencies = await api('/agencies');
                agencyOptions = agencies.map(a => `<option value="${a.agency_id}" ${data?.agency_id == a.agency_id ? 'selected' : ''}>${a.agency_name}</option>`).join('');
            }
            if (['properties', 'listings'].includes(table)) {
                const agents = await api('/agents');
                agentOptions = agents.map(a => `<option value="${a.agent_id}" ${data?.agent_id == a.agent_id ? 'selected' : ''}>${a.first_name} ${a.last_name}</option>`).join('');
            }
            if (['properties'].includes(table)) {
                const types = await api('/property-types');
                propertyTypeOptions = types.map(t => `<option value="${t.type_id}" ${data?.type_id == t.type_id ? 'selected' : ''}>${t.type_name}</option>`).join('');
                const locations = await api('/locations');
                locationOptions = locations.map(l => `<option value="${l.location_id}" ${data?.location_id == l.location_id ? 'selected' : ''}>${l.address}, ${l.area}</option>`).join('');
            }
            if (['transactions', 'inspections'].includes(table)) {
                const clients = await api('/clients');
                clientOptions = clients.map(c => `<option value="${c.client_id}" ${data?.client_id == c.client_id ? 'selected' : ''}>${c.first_name} ${c.last_name}</option>`).join('');
            }
            if (['transactions', 'inspections'].includes(table)) {
                const listings = await api('/listings');
                // Store listings globally for agent lookup in transactions
                window._listingsData = listings;
                listingOptions = listings.map(l => `<option value="${l.listing_id}" data-agent="${l.agent_name || 'N/A'}" ${data?.listing_id == l.listing_id ? 'selected' : ''}>#${l.listing_id} - ${l.property_title || 'Property'} (Agent: ${l.agent_name || 'N/A'})</option>`).join('');
            }
            if (['payments', 'contracts'].includes(table)) {
                const transactions = await api('/transactions');
                transactionOptions = transactions.map(t => `<option value="${t.transaction_id}" ${data?.transaction_id == t.transaction_id ? 'selected' : ''}>#${t.transaction_id} - ${t.property_title || 'Transaction'}</option>`).join('');
            }
        } catch (e) {
            console.error('Error loading dropdown data:', e);
        }

        const forms = {
            'agencies': `
                <div class="form-group"><label class="form-label">Agency Name *</label><input name="agency_name" class="form-input" value="${data?.agency_name || ''}" required></div>
                <div class="form-group"><label class="form-label">Email *</label><input name="email" type="email" class="form-input" value="${data?.email || ''}" required ${data ? 'readonly' : ''}></div>
                ${!data ? '<div class="form-group"><label class="form-label">Password *</label><input name="password" type="password" class="form-input" required></div>' : ''}
                <div class="form-group"><label class="form-label">Phone</label><input name="phone" class="form-input" value="${data?.phone || ''}"></div>
                <div class="form-group"><label class="form-label">Address</label><input name="address" class="form-input" value="${data?.address || ''}"></div>
                <div class="form-group"><label class="form-label">License Number</label><input name="license_number" class="form-input" value="${data?.license_number || ''}"></div>
                ${data ? '<div class="form-group"><label class="form-label"><input type="checkbox" name="is_active" ' + (data?.is_active ? 'checked' : '') + '> Active</label></div>' : ''}
            `,
            'agents': `
                <div class="form-group"><label class="form-label">Agency *</label><select name="agency_id" class="form-select" required><option value="">Select Agency</option>${agencyOptions}</select></div>
                <div class="form-group"><label class="form-label">First Name *</label><input name="first_name" class="form-input" value="${data?.first_name || ''}" required></div>
                <div class="form-group"><label class="form-label">Last Name *</label><input name="last_name" class="form-input" value="${data?.last_name || ''}" required></div>
                <div class="form-group"><label class="form-label">Email *</label><input name="email" type="email" class="form-input" value="${data?.email || ''}" required ${data ? 'readonly' : ''}></div>
                ${!data ? '<div class="form-group"><label class="form-label">Password *</label><input name="password" type="password" class="form-input" required></div>' : ''}
                <div class="form-group"><label class="form-label">Phone</label><input name="phone" class="form-input" value="${data?.phone || ''}"></div>
                <div class="form-group"><label class="form-label">License Number</label><input name="license_number" class="form-input" value="${data?.license_number || ''}"></div>
                <div class="form-group"><label class="form-label">Commission Rate %</label><input name="commission_rate" type="number" step="0.01" class="form-input" value="${data?.commission_rate || 2.5}"></div>
                ${data ? '<div class="form-group"><label class="form-label"><input type="checkbox" name="is_active" ' + (data?.is_active ? 'checked' : '') + '> Active</label></div>' : ''}
            `,
            'clients': `
                <div class="form-group"><label class="form-label">First Name *</label><input name="first_name" class="form-input" value="${data?.first_name || ''}" required></div>
                <div class="form-group"><label class="form-label">Last Name *</label><input name="last_name" class="form-input" value="${data?.last_name || ''}" required></div>
                <div class="form-group"><label class="form-label">Email *</label><input name="email" type="email" class="form-input" value="${data?.email || ''}" required ${data ? 'readonly' : ''}></div>
                ${!data ? '<div class="form-group"><label class="form-label">Password *</label><input name="password" type="password" class="form-input" required></div>' : ''}
                <div class="form-group"><label class="form-label">Phone</label><input name="phone" class="form-input" value="${data?.phone || ''}"></div>
                <div class="form-group"><label class="form-label">Address</label><input name="address" class="form-input" value="${data?.address || ''}"></div>
                <div class="form-group"><label class="form-label">CNIC</label><input name="cnic" class="form-input" placeholder="12345-1234567-1" value="${data?.cnic || ''}"></div>
                <div class="form-group"><label class="form-label">Type</label>
                    <select name="client_type" class="form-select">
                        <option value="Buyer" ${data?.client_type === 'Buyer' ? 'selected' : ''}>Buyer</option>
                        <option value="Seller" ${data?.client_type === 'Seller' ? 'selected' : ''}>Seller</option>
                        <option value="Renter" ${data?.client_type === 'Renter' ? 'selected' : ''}>Renter</option>
                        <option value="Landlord" ${data?.client_type === 'Landlord' ? 'selected' : ''}>Landlord</option>
                    </select>
                </div>
                ${data ? '<div class="form-group"><label class="form-label"><input type="checkbox" name="is_active" ' + (data?.is_active ? 'checked' : '') + '> Active</label></div>' : ''}
            `,
            'properties': `
                <div class="form-group"><label class="form-label">Title *</label><input name="title" class="form-input" value="${data?.title || ''}" required></div>
                <div class="form-group"><label class="form-label">Agent *</label><select name="agent_id" class="form-select" required><option value="">Select Agent</option>${agentOptions}</select></div>
                <div class="form-group"><label class="form-label">Property Type *</label><select name="type_id" class="form-select" required><option value="">Select Type</option>${propertyTypeOptions}</select></div>
                <div class="form-group"><label class="form-label">Location *</label><select name="location_id" class="form-select" required><option value="">Select Location</option>${locationOptions}</select></div>
                <div class="form-group"><label class="form-label">Price (PKR) *</label><input name="price" type="number" class="form-input" value="${data?.price || ''}" required></div>
                <div class="form-group"><label class="form-label">Area (sqft)</label><input name="area_sqft" type="number" class="form-input" value="${data?.area_sqft || ''}"></div>
                <div class="form-group"><label class="form-label">Bedrooms</label><input name="bedrooms" type="number" class="form-input" value="${data?.bedrooms || 0}"></div>
                <div class="form-group"><label class="form-label">Bathrooms</label><input name="bathrooms" type="number" class="form-input" value="${data?.bathrooms || 0}"></div>
                <div class="form-group"><label class="form-label">Year Built</label><input name="year_built" type="number" class="form-input" value="${data?.year_built || ''}"></div>
                <div class="form-group"><label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="Available" ${data?.status === 'Available' ? 'selected' : ''}>Available</option>
                        <option value="Pending" ${data?.status === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Sold" ${data?.status === 'Sold' ? 'selected' : ''}>Sold</option>
                        <option value="Rented" ${data?.status === 'Rented' ? 'selected' : ''}>Rented</option>
                        <option value="Off-Market" ${data?.status === 'Off-Market' ? 'selected' : ''}>Off-Market</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label">For</label>
                    <select name="property_for" class="form-select">
                        <option value="Sale" ${data?.property_for === 'Sale' ? 'selected' : ''}>Sale</option>
                        <option value="Rent" ${data?.property_for === 'Rent' ? 'selected' : ''}>Rent</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea">${data?.description || ''}</textarea></div>
            `,
            'listings': `
                <div class="form-group"><label class="form-label">Property *</label><select name="property_id" class="form-select" required disabled><option>${data?.property_title || 'Linked to property'}</option></select></div>
                <div class="form-group"><label class="form-label">Agent *</label><select name="agent_id" class="form-select" required><option value="">Select Agent</option>${agentOptions}</select></div>
                <div class="form-group"><label class="form-label">Listing Price (PKR) *</label><input name="listing_price" type="number" class="form-input" value="${data?.listing_price || ''}" required></div>
                <div class="form-group"><label class="form-label">Listing Date</label><input name="listing_date" type="date" class="form-input" value="${data?.listing_date ? data.listing_date.split('T')[0] : ''}"></div>
                <div class="form-group"><label class="form-label">Expiry Date</label><input name="expiry_date" type="date" class="form-input" value="${data?.expiry_date ? data.expiry_date.split('T')[0] : ''}"></div>
                <div class="form-group"><label class="form-label">Status</label>
                    <select name="listing_status" class="form-select">
                        <option value="Active" ${data?.listing_status === 'Active' ? 'selected' : ''}>Active</option>
                        <option value="Inactive" ${data?.listing_status === 'Inactive' ? 'selected' : ''}>Inactive</option>
                        <option value="Sold" ${data?.listing_status === 'Sold' ? 'selected' : ''}>Sold</option>
                        <option value="Expired" ${data?.listing_status === 'Expired' ? 'selected' : ''}>Expired</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label"><input type="checkbox" name="featured" ${data?.featured ? 'checked' : ''}> Featured Listing</label></div>
                <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea">${data?.description || ''}</textarea></div>
            `,
            'transactions': `
                <div class="form-group"><label class="form-label">Listing *</label><select name="listing_id" class="form-select" required onchange="updateAgentFromListing(this)"><option value="">Select Listing</option>${listingOptions}</select></div>
                <div class="form-group"><label class="form-label">Receiving Agent (Commission)</label><input name="agent_display" id="agentDisplayField" class="form-input" value="${data?.agent_name || ''}" readonly style="background-color: #f0f0f0; cursor: not-allowed;"></div>
                <div class="form-group"><label class="form-label">Client *</label><select name="client_id" class="form-select" required><option value="">Select Client</option>${clientOptions}</select></div>
                <div class="form-group"><label class="form-label">Type *</label>
                    <select name="transaction_type" class="form-select" required>
                        <option value="Sale" ${data?.transaction_type === 'Sale' ? 'selected' : ''}>Sale</option>
                        <option value="Rent" ${data?.transaction_type === 'Rent' ? 'selected' : ''}>Rent</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label">Transaction Date *</label><input name="transaction_date" type="date" class="form-input" value="${data?.transaction_date ? data.transaction_date.split('T')[0] : ''}" required></div>
                <div class="form-group"><label class="form-label">Amount (PKR) *</label><input name="amount" type="number" class="form-input" value="${data?.amount || ''}" required></div>
                <div class="form-group"><label class="form-label">Commission (PKR)</label><input name="commission" type="number" class="form-input" value="${data?.commission || ''}"></div>
                <div class="form-group"><label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="Pending" ${data?.status === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Completed" ${data?.status === 'Completed' ? 'selected' : ''}>Completed</option>
                        <option value="Cancelled" ${data?.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label">Notes</label><textarea name="notes" class="form-textarea">${data?.notes || ''}</textarea></div>
            `,
            'payments': `
                <div class="form-group"><label class="form-label">Transaction *</label><select name="transaction_id" class="form-select" required><option value="">Select Transaction</option>${transactionOptions}</select></div>
                <div class="form-group"><label class="form-label">Payment Date *</label><input name="payment_date" type="date" class="form-input" value="${data?.payment_date ? data.payment_date.split('T')[0] : ''}" required></div>
                <div class="form-group"><label class="form-label">Amount (PKR) *</label><input name="amount" type="number" class="form-input" value="${data?.amount || ''}" required></div>
                <div class="form-group"><label class="form-label">Payment Method</label>
                    <select name="payment_method" class="form-select">
                        <option value="Cash" ${data?.payment_method === 'Cash' ? 'selected' : ''}>Cash</option>
                        <option value="Bank Transfer" ${data?.payment_method === 'Bank Transfer' ? 'selected' : ''}>Bank Transfer</option>
                        <option value="Cheque" ${data?.payment_method === 'Cheque' ? 'selected' : ''}>Cheque</option>
                        <option value="Online" ${data?.payment_method === 'Online' ? 'selected' : ''}>Online</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label">Status</label>
                    <select name="payment_status" class="form-select">
                        <option value="Pending" ${data?.payment_status === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Completed" ${data?.payment_status === 'Completed' ? 'selected' : ''}>Completed</option>
                        <option value="Failed" ${data?.payment_status === 'Failed' ? 'selected' : ''}>Failed</option>
                        <option value="Refunded" ${data?.payment_status === 'Refunded' ? 'selected' : ''}>Refunded</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label">Reference Number</label><input name="reference_number" class="form-input" value="${data?.reference_number || ''}"></div>
                <div class="form-group"><label class="form-label">Notes</label><textarea name="notes" class="form-textarea">${data?.notes || ''}</textarea></div>
            `,
            'contracts': `
                <div class="form-group"><label class="form-label">Transaction *</label><select name="transaction_id" class="form-select" required><option value="">Select Transaction</option>${transactionOptions}</select></div>
                <div class="form-group"><label class="form-label">Contract Date *</label><input name="contract_date" type="date" class="form-input" value="${data?.contract_date ? data.contract_date.split('T')[0] : ''}" required></div>
                <div class="form-group"><label class="form-label">Start Date *</label><input name="start_date" type="date" class="form-input" value="${data?.start_date ? data.start_date.split('T')[0] : ''}" required></div>
                <div class="form-group"><label class="form-label">End Date</label><input name="end_date" type="date" class="form-input" value="${data?.end_date ? data.end_date.split('T')[0] : ''}"></div>
                <div class="form-group"><label class="form-label">Contract Type *</label>
                    <select name="contract_type" class="form-select" required>
                        <option value="Sale" ${data?.contract_type === 'Sale' ? 'selected' : ''}>Sale</option>
                        <option value="Rental" ${data?.contract_type === 'Rental' ? 'selected' : ''}>Rental</option>
                        <option value="Lease" ${data?.contract_type === 'Lease' ? 'selected' : ''}>Lease</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="Draft" ${data?.status === 'Draft' ? 'selected' : ''}>Draft</option>
                        <option value="Active" ${data?.status === 'Active' ? 'selected' : ''}>Active</option>
                        <option value="Completed" ${data?.status === 'Completed' ? 'selected' : ''}>Completed</option>
                        <option value="Terminated" ${data?.status === 'Terminated' ? 'selected' : ''}>Terminated</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label">Terms</label><textarea name="terms" class="form-textarea">${data?.terms || ''}</textarea></div>
            `,
            'inspections': `
                <div class="form-group"><label class="form-label">Listing *</label><select name="listing_id" class="form-select" required><option value="">Select Listing</option>${listingOptions}</select></div>
                <div class="form-group"><label class="form-label">Client *</label><select name="client_id" class="form-select" required><option value="">Select Client</option>${clientOptions}</select></div>
                <div class="form-group"><label class="form-label">Inspection Date *</label><input name="inspection_date" type="date" class="form-input" value="${data?.inspection_date ? data.inspection_date.split('T')[0] : ''}" required></div>
                <div class="form-group"><label class="form-label">Inspection Time *</label><input name="inspection_time" type="time" class="form-input" value="${data?.inspection_time || ''}" required></div>
                <div class="form-group"><label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="Scheduled" ${data?.status === 'Scheduled' ? 'selected' : ''}>Scheduled</option>
                        <option value="Completed" ${data?.status === 'Completed' ? 'selected' : ''}>Completed</option>
                        <option value="Cancelled" ${data?.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                        <option value="No-Show" ${data?.status === 'No-Show' ? 'selected' : ''}>No-Show</option>
                    </select>
                </div>
                <div class="form-group"><label class="form-label">Notes</label><textarea name="notes" class="form-textarea">${data?.notes || ''}</textarea></div>
                ${data ? '<div class="form-group"><label class="form-label">Agent Feedback</label><textarea name="agent_feedback" class="form-textarea">' + (data?.agent_feedback || '') + '</textarea></div>' : ''}
            `,
            'locations': `
                <div class="form-group"><label class="form-label">Address *</label><input name="address" class="form-input" value="${data?.address || ''}" required></div>
                <div class="form-group"><label class="form-label">Area</label><input name="area" class="form-input" value="${data?.area || ''}"></div>
                <div class="form-group"><label class="form-label">City</label><input name="city" class="form-input" value="${data?.city || 'Islamabad'}"></div>
                <div class="form-group"><label class="form-label">Postal Code</label><input name="postal_code" class="form-input" value="${data?.postal_code || '44000'}"></div>
            `,
            'property-types': `
                <div class="form-group"><label class="form-label">Type Name *</label><input name="type_name" class="form-input" value="${data?.type_name || ''}" required></div>
                <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea">${data?.description || ''}</textarea></div>
            `
        };
        return forms[table] || '<p>Form not available for this table</p>';
    }

    // Logout function
    window.logout = function () {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
    };

    // Initial load
    loadDashboard();
})();
