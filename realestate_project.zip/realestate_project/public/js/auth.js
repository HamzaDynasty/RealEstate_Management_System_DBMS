// Authentication Utilities
const API_URL = '/api';

// Token management
const Auth = {
    getToken() {
        return localStorage.getItem('token');
    },

    setToken(token) {
        localStorage.setItem('token', token);
    },

    removeToken() {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
    },

    getUser() {
        const user = localStorage.getItem('user');
        return user ? JSON.parse(user) : null;
    },

    setUser(user) {
        localStorage.setItem('user', JSON.stringify(user));
    },

    isAuthenticated() {
        return !!this.getToken();
    },

    getAuthHeaders() {
        const token = this.getToken();
        return token ? { 'Authorization': `Bearer ${token}` } : {};
    },

    logout() {
        this.removeToken();
        window.location.href = '/';
    }
};

// API request helper
async function apiRequest(endpoint, options = {}) {
    const url = `${API_URL}${endpoint}`;
    const headers = {
        'Content-Type': 'application/json',
        ...Auth.getAuthHeaders(),
        ...options.headers
    };

    try {
        const response = await fetch(url, {
            ...options,
            headers
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Request failed');
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Login function
async function login(role, email, password) {
    try {
        const data = await apiRequest(`/auth/${role}/login`, {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });

        if (data.success) {
            Auth.setToken(data.token);
            Auth.setUser(data.user);

            // Redirect based on role
            switch (role) {
                case 'admin':
                    window.location.href = '/admin-dashboard';
                    break;
                case 'agent':
                    window.location.href = '/agent-dashboard';
                    break;
                case 'client':
                    window.location.href = '/client-dashboard';
                    break;
            }
        }

        return data;
    } catch (error) {
        throw error;
    }
}

// Signup function
async function signup(role, userData) {
    try {
        const data = await apiRequest(`/auth/${role}/signup`, {
            method: 'POST',
            body: JSON.stringify(userData)
        });

        if (data.success) {
            Auth.setToken(data.token);
            Auth.setUser(data.user);

            // Redirect based on role
            switch (role) {
                case 'admin':
                    window.location.href = '/admin-dashboard';
                    break;
                case 'agent':
                    window.location.href = '/agent-dashboard';
                    break;
                case 'client':
                    window.location.href = '/client-dashboard';
                    break;
            }
        }

        return data;
    } catch (error) {
        throw error;
    }
}

// Check if user is authenticated and redirect if not
function requireAuth(allowedRoles = []) {
    if (!Auth.isAuthenticated()) {
        window.location.href = '/';
        return false;
    }

    const user = Auth.getUser();
    if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
        window.location.href = '/';
        return false;
    }

    return true;
}

// Format currency (PKR)
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-PK', {
        style: 'currency',
        currency: 'PKR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

// Format date
function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-PK', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Show alert message
function showAlert(message, type = 'success') {
    const alertEl = document.createElement('div');
    alertEl.className = `alert alert-${type}`;
    alertEl.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;margin-left:auto;">×</button>
    `;

    const container = document.querySelector('.alert-container') || document.body;
    container.insertBefore(alertEl, container.firstChild);

    setTimeout(() => alertEl.remove(), 5000);
}

// Show loading spinner
function showLoading(container) {
    container.innerHTML = `
        <div class="loading">
            <div class="spinner"></div>
        </div>
    `;
}

// Show empty state
function showEmptyState(container, message = 'No data found') {
    container.innerHTML = `
        <div class="empty-state">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/>
            </svg>
            <p>${message}</p>
        </div>
    `;
}

// Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Export utilities
window.Auth = Auth;
window.apiRequest = apiRequest;
window.login = login;
window.signup = signup;
window.requireAuth = requireAuth;
window.formatCurrency = formatCurrency;
window.formatDate = formatDate;
window.showAlert = showAlert;
window.showLoading = showLoading;
window.showEmptyState = showEmptyState;
window.debounce = debounce;
