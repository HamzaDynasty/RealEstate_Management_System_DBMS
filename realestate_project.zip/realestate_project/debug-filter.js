const pool = require('./config/db');

async function test() {
    try {
        // Check all properties with their listings
        console.log('\n=== All Properties with Listings ===');
        const [all] = await pool.query(`
            SELECT p.property_id, p.title, p.property_for, p.status, l.listing_status
            FROM Property p 
            JOIN Listing l ON p.property_id = l.property_id
        `);
        all.forEach(x => console.log(`ID:${x.property_id}, For:${x.property_for}, PropStatus:${x.status}, ListStatus:${x.listing_status}`));

        // Check what the filter query returns
        console.log('\n=== Testing Sale filter ===');
        const [saleProps] = await pool.query(`
            SELECT p.property_id, p.title, p.property_for
            FROM Listing l
            JOIN Property p ON l.property_id = p.property_id
            WHERE l.listing_status = 'Active' AND p.status = 'Available' AND p.property_for = 'Sale'
        `);
        console.log('Sale properties found:', saleProps.length);

        console.log('\n=== Testing Rent filter ===');
        const [rentProps] = await pool.query(`
            SELECT p.property_id, p.title, p.property_for
            FROM Listing l
            JOIN Property p ON l.property_id = p.property_id
            WHERE l.listing_status = 'Active' AND p.status = 'Available' AND p.property_for = 'Rent'
        `);
        console.log('Rent properties found:', rentProps.length);

        process.exit(0);
    } catch (e) {
        console.error(e);
        process.exit(1);
    }
}
test();
