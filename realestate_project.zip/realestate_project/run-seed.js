// Script to run seed data and reset passwords
const bcrypt = require('bcryptjs');
const pool = require('./config/db');
const fs = require('fs');
const path = require('path');

async function runSeedData() {
    console.log('Running seed data script...\n');

    try {
        // Read the SQL file
        const sqlFile = path.join(__dirname, 'database', 'seed_data.sql');
        let sql = fs.readFileSync(sqlFile, 'utf8');

        // Split by semicolons and filter empty statements
        const statements = sql.split(';').filter(s => s.trim().length > 0);

        console.log(`Found ${statements.length} SQL statements to execute...\n`);

        for (let i = 0; i < statements.length; i++) {
            const stmt = statements[i].trim();
            if (stmt && !stmt.startsWith('--') && !stmt.startsWith('SELECT \'Data')) {
                try {
                    await pool.query(stmt);
                    if (i % 10 === 0) {
                        process.stdout.write(`Executed ${i + 1}/${statements.length} statements...\r`);
                    }
                } catch (err) {
                    // Ignore some expected errors
                    if (!err.message.includes('Query was empty')) {
                        console.error(`\nWarning at statement ${i + 1}: ${err.message.substring(0, 100)}`);
                    }
                }
            }
        }

        console.log('\n\n✅ Seed data imported successfully!\n');

        // Show summary
        const tables = ['Agency', 'Property_Type', 'Location', 'Agent', 'Client', 'Property', 'Listing', 'Transaction', 'Payment', 'Contract', 'Inspection', 'Feedback'];

        console.log('📊 Database Summary:');
        console.log('═'.repeat(40));

        for (const table of tables) {
            try {
                const [rows] = await pool.query(`SELECT COUNT(*) as count FROM ${table}`);
                console.log(`   ${table.padEnd(20)} ${rows[0].count} records`);
            } catch (e) {
                console.log(`   ${table.padEnd(20)} Error: ${e.message}`);
            }
        }

        console.log('═'.repeat(40));

        // Show login credentials
        console.log('\n🔑 Login Credentials (password: password123 for all):');
        console.log('─'.repeat(50));

        const [agencies] = await pool.query('SELECT agency_name, email FROM Agency LIMIT 3');
        console.log('\n👔 Admins:');
        agencies.forEach(a => console.log(`   ${a.email}`));

        const [agents] = await pool.query('SELECT first_name, last_name, email FROM Agent LIMIT 5');
        console.log('\n🏠 Agents:');
        agents.forEach(a => console.log(`   ${a.email} (${a.first_name} ${a.last_name})`));

        const [clients] = await pool.query('SELECT first_name, last_name, email FROM Client LIMIT 5');
        console.log('\n👤 Clients:');
        clients.forEach(c => console.log(`   ${c.email} (${c.first_name} ${c.last_name})`));

        console.log('\n✅ All passwords are: password123');

        process.exit(0);
    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

runSeedData();
